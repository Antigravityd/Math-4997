# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 14:15:41 2019

@author: Rob Quarles
@author: zjermain15
@author: Ryan Leigon
"""

import FT_Interpreter as fti
import FT_Hom_Ops as hom
import FT_Help_File as h
import FT_Cache_Manager as cache

"""
conjecture check:

"""
def check_Conjecture(s,m):
    to_check = []
    for p in range(s, m):
        for a in range(1, p):
            for b in range (0, p):
                for r in range(1, p):
                    T = [p, a, b, r]
                    
                    if fti.fourtuple_Loop(p, a, b, r)[0] == False:
                        
                        print("Valid: ", T)
                        test_C = hom.gen_Complex(T)
                        V = hom.make_Vert(test_C[0], test_C[1])
                        #print(V)
                        maxi = -9999
                        for gen in range(len(V[1])):
                            if V[1][gen][2] > maxi: maxi = V[1][gen][2]
                        
                        #check second slot
                        check = maxi - 1
                        #print("Checking: ", check)
                        exists = False
                        for gen in range(len(V[1])):
                            if V[1][gen][2] == check: 
                                exists = True
                        
                        if exists == False: 
                            to_check.append(T)
    print("Check: ", to_check)                        
    print("Done")
    return 

def check_For_Trivial_Alexander(s,m):
    to_check = []
    for p in range(s, m):
        
        print("checking p = ", p)
        for a in range(1, p):
            for b in range (0, p):
                for r in range(1, p):
                    T = [p, a, b, r]
                    
                    if fti.fourtuple_Loop(p, a, b, r)[0] == False:
                        print(T)
                        test_C = hom.gen_Complex(T)
                        V = hom.make_Vert(test_C[0], test_C[1])
                        euler = hom.calc_Euler_Char(T, V)
                        throw_out = []
                        for pair in euler:
                            if pair[0] == 0: throw_out.append(pair)
                        for pair in throw_out: euler.remove(pair)
                        if euler == [[1,0]]: 
                            to_check.append(T)
                            s3temp = hom.calc_S3(V[0], V[1])
                            print("Found: ", T, ", tau: ", hom.get_Tau(s3temp, V[1]), ", Epsilon: ",hom.calc_Epsilon(hom.calc_Leftarm(V[0], V[1]), hom.calc_Rightarm(V[0], V[1]))  )
        print("Check through ",p, ": ", to_check)
        print("\n")
                        
                           
    print("Done")
    return 


"""
MAIN
"""
h.intro()
debug = [False]
show_final_diskset = False

#test = [[7,3,1,5]]
#test = [[13,3,4,3]]
#Some test code and cases
#mike_test = [([(1, 2)], 2, 0), ([(1, 3)], 1, 0), ([(1, 4)], 0, 1), ([(2, 3)], 0, 1), ([(4, 3)], 2, 0)]
#mike_grad = [[1, 0, 1],[2, 0, -1],[3, 0, 0],[4, 0, 2]]

"""
#debug = [fds cutout passes]
debug = [False]
t = sym.Symbol('t')
"""

test = []
#test.append([7,3,1,5])
#test.append([7,2,1,3])
#test.append([9,2,3,2]) 
#test.append([3,1,1,1]) #3_1
#test.append([5,2,1,4] ) #4_1
#test.append([19,3,12,3])
#test.append([13,3,4,3]) #10_161
#test.append([13,5,3,1])
#test.append([9,4,1,1])
#test.append([13,4,1,6]) 
#test.append([13,5,3,1])
#test.append([7,3,1,5])
#test.append([7,2,1,3])
#test.append([13,4,1,6])
#test.append([9,2,3,2])
#Trivial Alexander Polynomial Examples
#test.append([31, 11, 1, 9])
#test.append([31, 11, 8, 15])
#test.append([31, 12, 1, 7])
#test.append([31, 12, 6, 19])

"""
test = [[7,2,1,3]]
"""

for test_4_tuple in test:
    
    print("\n")
    print(test_4_tuple)
    fun_complex = hom.gen_Complex(test_4_tuple)
    hat = hom.calc_Hat(fun_complex[0], fun_complex[1])
    print("S3 gen: ", hom.calc_S3(hat[0], hat[1]), ", Tau: ", hom.get_Tau(hom.calc_S3(hat[0], hat[1]), hat[1]))
    print("Spectral Sequence: ", hom.spec_Sequence(hat[0], hat[1]))
    V = hom.make_Vert(fun_complex[0],fun_complex[1])
    print("\n")
    print("Epsilon: ", hom.calc_Epsilon(hom.calc_Leftarm(V[0], V[1]), hom.calc_Rightarm(V[0], V[1])))

