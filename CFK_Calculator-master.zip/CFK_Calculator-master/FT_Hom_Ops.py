# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 12:06:10 2020

@author: Rob Quarles
"""
import sys 
import copy
import itertools
import math

import FT_Interpreter as fti

"""
generate_Complex

z - vertical shift
w - horizontal shift (pass over U get Ub (so b sits above a)) go over tiwce means
    arrow twice as long, and b sits two units above a
    
    Need to figure out how to sort info into a graph in the plane, using relative 
    positions of generators

Relative Alexander Gradings

Relative Maslov Grading

Absolute Maslov Grading

Tau -> Wil contract length 0 arrows, then length 1 arrows, etc.
--> Need to be able to stop at each stage (actually computing pages of spectral sequence)

Epsilon

Upsilon

Calc Maslovs, See if any thin are not sigma thin
~ thin is support on maslov/alexander gradings slope 1
~ sigma thin is y-intercept is -sigma/2 for sigma is classical signature

"""

def find_Coords(disks, four_tuple): #Only works if there is a spanning tree
    n = four_tuple[0]
        
    #blank coordinate list
    coords = []
    
    #generate starting coords, let 'em all be a 0,0
    for i in range(1,n+1):
        coords.append([i, 0, 0])
    
    #find the spanning tree using the relations
    pos = [1]
    head = []
    tail = []
    used = []
    new = []
    placed = [1]
    
    while len(used) < n:
        
        for dot in pos:
            if dot not in used:
                #put it in the pile
                used.append(dot)
                
                #Get relaions it is the head of
                #Get relations it it the tail of
                for disk in disks:
                    if disk[0][0][1] == dot and disk[0][0][0] not in used: #at head
                        head.append(disk)
                    elif disk[0][0][0] == dot and disk[0][0][1] not in used: # at tail
                        tail.append(disk)
                        
                if fti.debug[0]: print("/n")
                if fti.debug[0]:print("dot: ",  dot)
                if fti.debug[0]: print("head of:",  head)
                if fti.debug[0]:print("tail of:",  tail)
                
                #apply relations from head, move down (z) and to the left (w)
                for rel in head:
                    if rel[0][0][0] not in placed: #if the geerator has not been placed yet
                        placed.append(rel[0][0][0])
                        coords[rel[0][0][0]-1] = [rel[0][0][0], coords[dot-1][1] + rel[2], coords[dot-1][2] + rel[1]]
                        if rel[0][0][0] not in new: new.append(rel[0][0][0]) #add to pile to  check
                    
    
                for rel in tail:
                    if rel[0][0][1] not in placed: #if the geerator has not been placed yet
                        placed.append(rel[0][0][1])
                        coords[rel[0][0][1]-1] = [rel[0][0][1], coords[dot-1][1] - rel[2], coords[dot-1][2] - rel[1]]
                        if rel[0][0][1] not in new: new.append(rel[0][0][1]) #add to pile to  check
                head = []
                tail = []    
        if fti.debug[0]: print("Now Checking: ", new)
        pos = new
        new = []
    
    i = 0
    for coord in coords:
        #coord.append(basis[i])
        i +=1
    
    return adjust_Alexander(coords) #[gen, U-power, j, basis]

def adjust_Alexander(coordinates):
    x = 100000
    y = 100000
    for coord in coordinates:
        if coord[1] < x: x = coord[1] #farthest left
        if coord[2] < y: y = coord[2] #Farthest down
    for coord in coordinates:
        coord[1] = coord[1]-x
        coord[2] = coord[2]-y
    return coordinates

"""
Make Hat: throw out W arrows, everything lives on axis (v)
Could calculate Euler Char which would fix Alexander grading (because its symmetric)
Maslov: Make hat, calc homology (i.e. contract) surviving one is at Maslov = 0
Absolute Alexander (calc after Euler Characterist)
Order Mike would write functions: 
    -MakeHat
    -Euler Char
    -Calc Abs Alexander
"""
def make_Hat(a_complex, coords):
    hat_complex = copy.deepcopy(a_complex) #we want to preserve the OG thing
    hat_coords = copy.deepcopy(coords) #we want to preserve the OG thing
    temp = []
    for disk in a_complex:
        if disk[2] != 0:
            temp.append(disk)
    
    for bad_disk in temp:
        hat_complex.remove(bad_disk)
    
    for gen in hat_coords:
        grading_shift = gen[1]
        gen[1] = 0
        gen[2] = gen[2] - grading_shift
    
    return [hat_complex, hat_coords]


"""
connect sum

Two sets of data: [C1, Co1], [C2, Co2]
New set:
    (c1i, c2j) <tensor generators together>
    -New arrow whenever a set of coords the same (c1i, c2j) and (c1i, c2k)
    AND there already exists an arrow from c2j -> c2k.
    
    option to rename tensored gens from 1 to nm changing arrows accordingly.
    
    !!!WIP!!!

"""
def connect_Sum(C1, C2, G1, G2):
    comp1 = C1
    comp2 = C2
    tensored_gens = []
    i = 0
    for c1 in comp1:
        for c2 in comp2:
            tensored_gens.append(i, (c1, c2))
            i += 1
    
    tensored_coords = []
    for gen in tensored_gens:
        tensored_coords.append([gen, G1[gen[0]-1][1] + G2[gen[1]-1][1], G1[gen[0]-1][2] + G2[gen[1]-1][2]])
        
    tensor_complex = []
    for pair1 in tensored_gens:
        for pair2 in tensored_gens:
            if pair1[1][1] != pair2[1][1] and pair1[1][0] == pair2[1][0]:
                ind1 = pair1[0]
                ind2 = pair2[0]
                for arrow in C2:
                    if arrow[0] == [(pair1[1][1], pair2[1][1])]:
                        tensor_complex.append([(pair1[1][0], pair2[1][0]), (pair1[1][1], pair2[1][1])], abs(tensored_coords[ind1][2] - tensored_coords[ind2][2]), abs(tensored_coords[ind1][1] - tensored_coords[ind2][1]))    
            elif pair1[1][1] != pair2[1][1] and pair1[1][1] == pair2[1][1]:
                ind1 = pair1[0]
                ind2 = pair2[0]
                for arrow in C2:
                    if arrow[0] == [(pair1[1][0], pair2[1][0])]:
                        tensor_complex.append([(pair1[1][0], pair2[1][0]), (pair1[1][1], pair2[1][1])], abs(tensored_coords[ind1][2] - tensored_coords[ind2][2]), abs(tensored_coords[ind1][1] - tensored_coords[ind2][1]))
    
    return [tensor_complex, tensored_coords]

"""
Contraction Algorithm (Fast, for hat complex)
- addModTwo: should 'add' arrows mod 2
- eat arrow (identify head and tail)
-- Get Parents (of head)
-- Get Children (of tail)
---tie parents to children (mod 2)
"""
def contract(arrow, a_complex, coords): #a disk (arrow) to remove, the complex, and the coords
    new_complex = copy.deepcopy(a_complex) #We dont want to change the original thing
    new_basis = copy.deepcopy(coords) #We dont want to change the original thing
    
    #Identify Head and Tail
    head = arrow[0][0][1]
    tail = arrow[0][0][0]
    
   
    
    #Get Parents of head
    parents = []
    temp = []
    for disk in new_complex:
        if disk[0][0][1] == head and disk[0][0][0] != tail: #throw out arrows into head, collect parents
            parents.append(disk[0][0][0])
            temp.append(disk)
        if disk[0][0][0] == head: #throw out arrows leaving head
            temp.append(disk)
    
    #Get Children of tail
    children = []
    for disk in new_complex:
        if disk[0][0][0] == tail and disk[0][0][1] != head: #throw out arrows leaving tail, collect child
            children.append(disk[0][0][1])
            temp.append(disk)
        if disk[0][0][1] == tail: #throw out arrows into tail
            temp.append(disk)
    
    #cleanup by throwing out the arrows. But FIRST we should have calculated new disks.
    #Its should be: new arrow equals: (parent to head) + (tail to child) - (arrow)
    for parent in parents:
        for child in children:
            new_arrow = []
            length_1 = []
            length_2 = []

            for disk in a_complex:
                #print("checking: ", disk)
                if disk[0] == [(parent, head)]:
                    length_1 = [disk[1], disk[2]]
                elif disk[0] == [(tail, child)]:
                    length_2 = [disk[1], disk[2]]
            
            new_arrow.append(([(parent, child)], length_1[0] + length_2[0] - arrow[1], length_1[1] + length_2[1] - arrow[2]))
            if new_arrow[0] in new_complex: #add mod2
                new_complex.remove(new_arrow[0])
            else: new_complex.append(new_arrow[0])                
    
    #Actual cleanup
    for disk in temp: 
        new_complex.remove(disk)            
    
    
    return [new_complex, new_basis]

"""
calc S3 generator
1. Contract length 1 arrows in CFK^
2. Check if done (is there an isolated generator?) if not:
2+i. Contract length 1+i arrows and check if done.

The isolated generator is the S3 generator. 
tau = A(S3 generator)
"""
def calc_S3(hat_complex, hat_coords):
    contracted_complex = copy.deepcopy(hat_complex) #We want to preserve the original hat complex
    quiver = []
    length = 1
    S3_gen = 0
    while S3_gen == 0:
        arrow_was_contracted = False
            
        #grab a length i arrow
        for arrow in contracted_complex:
            if arrow[1] == length and arrow not in quiver: 
                quiver.append(arrow)
                contracted_complex = contract(arrow, contracted_complex, hat_coords)[0]
                arrow_was_contracted = True
                break
                
        if not arrow_was_contracted: 
            length += 1
            #check if done          
            for gen in hat_coords: #More robust indexing than original calc_S3
                is_isolated = True
                for disk in contracted_complex: 
                    if disk[0][0][0] == gen[0] or disk[0][0][1] == gen[0]: is_isolated = False 
                if is_isolated: 
                    S3_gen = gen[0]
                    break
        
        if length > 1000: sys.exit("I'ma keep on runnin' (arrow length exceeded 1000, if for some reason this is not unreasonable get rid of this sys.exit line)")
        
    return S3_gen

def spec_Sequence(hat_complex, hat_coords): 
    contracted_complex = copy.deepcopy(hat_complex) #We want to preserve the original hat complex
    quiver = []
    length = 1
    S3_gen = 0
    Ecounter = 0
    Esequence = []
    while S3_gen == 0:
        arrow_was_contracted = False
            
        #grab a length i arrow
        for arrow in contracted_complex:
            if arrow[1] == length and arrow not in quiver: 
                quiver.append(arrow)
                contracted_complex = contract(arrow, contracted_complex, hat_coords)[0]
                arrow_was_contracted = True
                break
        if not arrow_was_contracted:
            E = [i for i in hat_complex if i not in quiver]
            Esequence.append(E)
            print("E[",Ecounter,"] =", E,)
            print("\n")
            length += 1
            Ecounter += 1
            #check if done
            for gen in range(1, len(hat_coords)+1):
                is_isolated = True
                for disk in contracted_complex: 
                    if disk[0][0][0] == gen or disk[0][0][1] == gen: is_isolated = False 
                if is_isolated: 
                    S3_gen = gen
                    E = []
                    print("E[",Ecounter,"] =", E,)
                    Esequence.append(E)
                    break
            
        
        if length > 1000: sys.exit("I'ma keep on runnin' (arrow length exceeded 1000, if for some reason this is not unreasonable get rid of this sys.exit line)")
        
    return Esequence
        

"""
Add Generators
remember: Raise tails, lower heads (by difference of the addon's A gradings)
a-> c (-> c+b)
a-> b
arrows into c+b get copied to b
Arrows out of c+b get copied to children of b

"""
def add_Generators(addon, addto, C, G):
    new_complex = copy.deepcopy(C)
    adjust = abs(get_A_Grading(addto, G) - get_A_Grading(addon, G))
    
    arrows_out = []
    for arrow in new_complex: 
        #grab arrows out of addon
        if arrow[0][0][0] == addon: arrows_out.append(arrow)
    
    for arrow in arrows_out:
        new_arrow = ([(addto, arrow[0][0][1])], arrow[1] + adjust , arrow[2])
        if new_arrow not in new_complex: 
            new_complex.append(new_arrow)
        else: new_complex.remove(new_arrow)
        
    arrows_in = []    
    for arrow in new_complex: 
        #grab arrows into of addto
        if arrow[0][0][1] == addto: arrows_in.append(arrow)

    for arrow in arrows_in: #just lower heads, they go to U^-i addon
        new_arrow = ([(arrow[0][0][0], addon)], arrow[1] + adjust, arrow[2])
        if new_arrow not in new_complex:
            new_complex.append(new_arrow)
        else: new_complex.remove(new_arrow)
        
    return new_complex

"""
Vertically Simplify
"""
def vert_Simplify(C, G):
    new_complex = copy.deepcopy(C)
    maxi = 0
    mini = 0
    
    for grads in G:
        if grads[2] > maxi: maxi = grads[2]
        if grads[2] < mini: mini = grads[2]
    
    max_length = maxi - mini
    
    #find length i vertical arrow, and add stuff until no length i vertical arrows
    length = 1
    quiver = []
    
    while length <= max_length:
        increase_length = True
        for arrow in new_complex:
            if arrow[2] == 0 and arrow[1] == length and arrow not in quiver: #only consider vertical arrows
                quiver.append(arrow)
                increase_length = False
                #get children of tail
                children = []
                for a in new_complex:
                    if a[0][0][0] == arrow[0][0][0] and a[0][0][1] != arrow[0][0][1] and a[2] == 0:
                        children.append(a[0][0][1])
                for child in children:
                    #print("adding ", child, " to ", arrow[0][0][1], " at length ", length)
                    new_complex = add_Generators(child, arrow[0][0][1], new_complex, G)
                
                #get parents of addto:
                parents = []
                for a in new_complex: 
                    if a[0][0][1] == arrow[0][0][1] and a[0][0][0] != arrow[0][0][0] and a[2] == 0:
                        parents.append(a[0][0][0])
                for parent in parents:
                    new_complex = add_Generators(arrow[0][0][0], parent, new_complex, G)
                
                break
            
        if increase_length: length += 1
    
    return new_complex

"""
Hor Simplify
!!!Untested!!!
"""
def hori_Simplify(C, G):
    new_complex = copy.deepcopy(C)
    maxi = 0
    mini = 0
    
    for grads in G:
        if grads[1] > maxi: maxi = grads[1]
        if grads[1] < mini: mini = grads[1]
    
    max_length = maxi - mini
    
    #find length i hori arrow, and add stuff until no length i hori arrows
    length = 1
    quiver = []
    
    while length <= max_length:
        increase_length = True
        for arrow in new_complex:
            if arrow[1] == 0 and arrow[2] == length and arrow not in quiver: #only consider hori arrows
                quiver.append(arrow)
                increase_length = False
                #get children of tail
                children = []
                for a in new_complex:
                    if a[0][0][0] == arrow[0][0][0] and a[0][0][1] != arrow[0][0][1] and a[1] == 0:
                        children.append(a[0][0][1])
                for child in children:
                    #print("adding ", child, " to ", arrow[0][0][1], " at length ", length)
                    new_complex = add_Generators(child, arrow[0][0][1], new_complex, G)
                
                #get parents of addto:
                parents = []
                for a in new_complex: 
                    if a[0][0][1] == arrow[0][0][1] and a[0][0][0] != arrow[0][0][0] and a[1] == 0:
                        parents.append(a[0][0][0])
                for parent in parents:
                    new_complex = add_Generators(arrow[0][0][0], parent, new_complex, G)
                
                break
            
        if increase_length: length += 1
    
    
    
    return new_complex

"""
===========================================
Grading Calculations
===========================================
"""

def rel_maslov(FT, C, gradings, startpoint, endpoint):
    x = startpoint
    y = endpoint
    #nz = gradings[x-1][2] - gradings[y-1][2] #calculates number of z basepoints
    nw = gradings[x-1][1] - gradings[y-1][1] #calculates number of w basebapoints
    phi = phi = get_phi(C,FT,x,y)      
    return phi -2*nw

#Computes relative Maslov grading between two generators; alternative to rel_maslov
def robust_Rel_Maslov(disks,coords, startpoint, endpoint): #takes in gradings of points and two points to find relative gradings
    x = startpoint
    y = endpoint

    for coord in coords:
        if coord[0] == x:
            x_coord = [coord[1],coord[2]]
        if coord[0] == y: #not using elif to allow us to compare a generator to itself
            y_coord = [coord[1],coord[2]]
    #nz = x_coord[1] - y_coord[1] #calculates number of z basepoints
    nw = x_coord[0] - y_coord[0] #calculates number of w basebapoints
    phi = robust_Get_Phi(disks,coords,x,y) #finds total number of arrows between points for Maslov gradings      
    return phi -2*nw

#Appends a Maslov grading to the bigrading of a complex
def make_Maslov(a_complex, coords):
    gcoords = []

    hat_complex = make_Hat(a_complex,coords)
    S3_gen = calc_S3(hat_complex[0],hat_complex[1])
    for coord in coords:
        maslov = robust_Rel_Maslov(a_complex,coords,coord[0],S3_gen)
        gcoord = [coord[0], 0,coord[2]-coord[1],maslov]
        gcoords.append(gcoord)
    return(a_complex,gcoords)

def rel_alexander(gradings,startpoint,endpoint):
    x = startpoint
    y = endpoint
    nz = gradings[x-1][2] - gradings[y-1][2] #calculates number of z basepoints
    nw = gradings[x-1][1] - gradings[y-1][1] #calculates number of w basebapoints      
    return nz - nw

def find_path(graph, start, end, path=[]): #finds path between two generators (used to calculate phi)
        path = path + [start]
        if start == end:
            return path
        #if not graph.has_key(start):
        #    return None
        for node in graph[start]:
            if node not in path:
                newpath = find_path(graph, node, end, path)
                if newpath: return newpath
        return None
    
def get_phi(disks,fourtuple,startingpoint,endingpoint): #calculates phi to get Maslov gradings
    graph = {} 
    n = fourtuple[0]
    phi = 0
    x = startingpoint
    y = endingpoint
    
    for i in range(n): #writes disks into a dictionary 
        relations = []
        for j in range(len(disks)) :
            if disks[j][0][0][0] == i+1:
                relations.append(disks[j][0][0][1])
            elif disks[j][0][0][1] == i+1:
                relations.append(disks[j][0][0][0])
            graph[i+1] = relations

    path = (find_path(graph,x,y)) #gets path between two points 

    for i in range(len(path) -1): #calculates phi
        for j in range(len(disks)): 
            if path[i] == disks[j][0][0][0] and path[i+1] == disks[j][0][0][1] : #adds 1 for forward arrow
                phi += 1 
            elif path[i] == disks[j][0][0][1] and path[i+1] == disks[j][0][0][0]: #subtracts one for backward arrow
                phi -= 1
    return phi

#A more robust versions of get_phi; works after forgetting the original 4-tuple
def robust_Get_Phi(disks,coords,startingpoint,endingpoint): #calculates phi to get Maslov gradings
    graph = {} 
    n = len(coords)
    phi = 0
    x = startingpoint
    y = endingpoint

    for i in range(n): #writes disks into a dictionary 
        relations = []
        for j in range(len(disks)) :
            if disks[j][0][0][0] == i+1:
                relations.append(disks[j][0][0][1])
            elif disks[j][0][0][1] == i+1:
                relations.append(disks[j][0][0][0])
            graph[i+1] = relations

    path = (find_path(graph,x,y)) #gets path between two points

    for i in range(len(path) -1): #calculates phi
        for j in range(len(disks)): 
            if path[i] == disks[j][0][0][0] and path[i+1] == disks[j][0][0][1] : #adds 1 for forward arrow
                phi += 1 
            elif path[i] == disks[j][0][0][1] and path[i+1] == disks[j][0][0][0]: #subtracts one for backward arrow
                phi -= 1

    return phi


"""
===========================================
calc_Euler_Char
===========================================
"""
def calc_Euler_Char(FT, C):
    CopyC = copy.deepcopy(C)
    hat = calc_Hat(CopyC[0], CopyC[1])
    S3 = calc_S3(hat[0], hat[1])
    maslov_gradings = calc_Maslov(CopyC[0], FT, CopyC[1], S3)
    min_alexander_grading = 0
    max_mas = 0
    min_mas = 0
    for gen in hat[1]:
        if  gen[2] < min_alexander_grading: min_alexander_grading =  gen[2]
        if maslov_gradings[gen[0] - 1] > max_mas: max_mas = maslov_gradings[gen[0] - 1]
        if maslov_gradings[gen[0] - 1] < min_mas: min_mas = maslov_gradings[gen[0] - 1]

    mas_range = abs(min_mas) + max_mas + 1

    alex = []
    for s in range(2* (abs(min_alexander_grading)) + 1):
        s_grad = min_alexander_grading + s
        temp = 0
        for i in range(mas_range):
            index = min_mas + i

            count = 0
            for gen in  hat[1]:
                if maslov_gradings[gen[0] - 1] == index and gen[2] == s_grad:
                    count += 1
            temp += ((-1)**index)*count
        alex.append([int(temp), s_grad])
    return alex



def calc_Maslov(C, FT, gradings, S3):
    maslov_gradings = []
    for i in range(1, len(gradings)+1): maslov_gradings.append(rel_maslov(FT, C, gradings, S3, i))
    return maslov_gradings

"""
===========================================
Epsilon
calc_Leftarm calcultaes the right arm complex starting at the S3 generator, ie the tau level 
===========================================

"""

def calc_Leftarm(C,G): #Feed a complex with gens on vertical axis, calculates left arm complex for epsilon calculation 
    AA = make_Vert(copy.deepcopy(C), G)
    new_complex = [vert_Simplify(AA[0], AA[1]), AA[1]]
    disks = new_complex[0]
    vert_gradings = new_complex[1]
    horizontal_gradings = horizontal_gens(vert_gradings)
    hat = calc_Hat(C,G) 
    S3_gen = calc_S3(hat[0],hat[1])
   
    current_gens = [S3_gen]
    used_gens = [S3_gen]
    left_arm = []
    special_gens = []
    
    left_arm_complex = horizontal_arm(disks, horizontal_gradings, S3_gen, left_arm, current_gens, used_gens, special_gens, 1)
    left_arm = left_arm_complex[0] #now have all horizontal arrows of left arm for first pass 
    specialgen_counter = len(left_arm_complex[3])
    
    keep_going = False 
    if specialgen_counter != 0: #checks if there were any generators at the same grading of S3 generator, if not we are done, if so we check for vertical arrows 
        keep_going = True 
    while keep_going: 
        keep_going = False
        left_arm_complex = vertical_arm(disks, vert_gradings, S3_gen, left_arm, left_arm_complex[1],left_arm_complex[2],left_arm_complex[3],1) #checks for vertical arrows 
        left_arm = left_arm_complex[0]
        #specialgen_counter == left_arm_complex[3]
        
        if len(left_arm_complex[3]) == specialgen_counter: #checks if there are any additional generators at the same grading of S3 generatr, if so we check for additional horizontal arrows
            keep_going = False
            break
        
        specialgen_counter = len(left_arm_complex[3])
        left_arm_complex = horizontal_arm(disks, horizontal_gradings, S3_gen,left_arm, left_arm_complex[1],left_arm_complex[2],left_arm_complex[3],2)
        left_arm = left_arm_complex[0] 
        
        if len(left_arm_complex[3]) != specialgen_counter: #checks if there are any additional generators at the same grading of the S3 generator, if so we check for more vertical arrows
            keep_going = True
            specialgen_counter = len(left_arm_complex[3])
    
    #print("left arm")
    #print(left_arm)
    #print("\n")
    #now contract left arm complex, see if homology is trivial 
    coords = []
    for i in range(len(used_gens)): # get coords for left arm
        if vert_gradings[used_gens[i] - 1][2] <= vert_gradings[S3_gen - 1][2]:
            coords.append(vert_gradings[used_gens[i] - 1])
        elif vert_gradings[used_gens[i] - 1][2] > vert_gradings[S3_gen -1][2]: 
            coords.append(horizontal_gradings[used_gens[i] -1])
        
    #print(coords)
    contracted_complex = copy.deepcopy(left_arm)
    
    return homology_survives(S3_gen, contracted_complex,  vert_gradings, 1)

           
def calc_Rightarm(C,G): #Feed a complex with gens on vertical axis, calculates right arm complex for epsilon calculation 
    
    AA = make_Vert(copy.deepcopy(C), G)
    new_complex = [vert_Simplify(AA[0], AA[1]), AA[1]]
    disks = new_complex[0]
    vert_gradings = new_complex[1]
    horizontal_gradings = horizontal_gens(vert_gradings)
    hat = calc_Hat(C,G) 
    S3_gen = calc_S3(hat[0],hat[1])
    
    #Right Arm
    #!!!Maybe add a check to first see if any arrows out.
    current_gens = [S3_gen]
    used_gens = [S3_gen]
    right_arm = []
    special_gens = []
    
    right_arm_complex = horizontal_arm(disks, horizontal_gradings, S3_gen, right_arm, current_gens, used_gens, special_gens, 3)
    right_arm = right_arm_complex[0] #now have all horizontal arrows of right arm for first pass 
    specialgen_counter = len(right_arm_complex[3])
    
    keep_going = False 
    if specialgen_counter != 0: #checks if there were any generators at the same grading of S3 generator, if not we are done, if so we check for vertical arrows 
        keep_going = True 
    while keep_going: 
        keep_going = False
        right_arm_complex = vertical_arm(disks, vert_gradings, S3_gen, right_arm, right_arm_complex[1],right_arm_complex[2],right_arm_complex[3],2) #checks for vertical arrows 
        right_arm = right_arm_complex[0] 
        
        if len(right_arm_complex[3]) == specialgen_counter: #checks if there are any additional generators at the same grading of S3 generatr, if so we check for additional horizontal arrows
            keep_going = False
            break
        
        specialgen_counter = len(right_arm_complex[3])
        right_arm_complex = horizontal_arm(disks, horizontal_gradings, S3_gen,right_arm, right_arm_complex[1],right_arm_complex[2],right_arm_complex[3],4)
        right_arm = right_arm_complex[0] 
        
        if len(right_arm_complex[3]) != specialgen_counter: #checks if there are any additional generators at the same grading of the S3 generator, if so we check for more vertical arrows
            keep_going = True
            specialgen_counter = len(right_arm_complex[3])
        
        #We now have the complex starting at the S3 gen, and everything "connected to it"
        #Need to compute homology now. i.e. contract arrows to see if arrows out of S3 gen survive.
        #now contract right arm complex, see if homology is trivial 
    #print("right arm")
    #print(right_arm)
    #print("\n")
    
    coords = []
    for i in range(len(used_gens)): # get coords for left arm
        if vert_gradings[used_gens[i] - 1][2] >= vert_gradings[S3_gen - 1][2]:
            coords.append(vert_gradings[used_gens[i] - 1])
        elif vert_gradings[used_gens[i] - 1][2] < vert_gradings[S3_gen -1][2]: 
            coords.append(horizontal_gradings[used_gens[i] -1])
        
    #print(coords)
    contracted_complex = copy.deepcopy(right_arm)
    
    return homology_survives(S3_gen, contracted_complex, vert_gradings, 0)

    
def horizontal_gens(G): #gives horizontal gradings
    gradings = G
    coord = []
    horizontal_gradings = []
    
    for i in range(len(G)): 
        coord.append(gradings[i][2])
        horizontal_gradings.append((gradings[i][0],-coord[i],gradings[i][1]))

    return horizontal_gradings
     
def horizontal_arm(C,G_horizontal,S3_gen,arm_complex,currentgens,usedgens,specialgens,startindex): #finds horizontal arrows for arm complexes
    
    disks = C 
    #vert_gradings = G_vert
    hor_gradings = G_horizontal
    #current_gens = currentgens 
    used_gens = usedgens
    keep_going = True
    arm = arm_complex
    special_gens = specialgens #will include generators that have same grading as S3_gen, could have vertical arrows
    
    if  startindex == 1: #finds all horizontal arrows for the first pass in the left arm complex 
        current_gens = currentgens
        while keep_going:
            keep_going = False
            children = []
            for current_gen in current_gens: #find children of current, add disks to new complex
                for disk in disks:
                    if disk[0][0][0] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm: #tail of horiz arrow, make sure it is in horizontal part of arm
                        arm.append(disk)
                        used_gens.append(disk[0][0][1])
                        children.append(disk[0][0][1])
                        if hor_gradings[disk[0][0][1] - 1][1] == hor_gradings[S3_gen - 1][1]: #adds generators that have same grading as S3_gen for vertical arrow chck
                            special_gens.append(disk[0][0][1])
                        
            current_gens = []
            for child in children: current_gens.append(child)
                        
            parents = []
            for current_gen in current_gens: #find parents of current, add disks to new complex
                for disk in disks:           
                    if disk[0][0][1] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm and hor_gradings[disk[0][0][0] - 1][1] <= hor_gradings[S3_gen - 1][1]:  #head of horiz arrow, makes sure it still lies in left arm
                        keep_going = True #Were there parents? Cycle through again
                        arm.append(disk)
                        used_gens.append(disk[0][0][0])
                        parents.append(disk[0][0][0])
                        if hor_gradings[disk[0][0][0] -1][1] == hor_gradings[S3_gen -1][1]: #adds generators that have same grading as S3_gen for vertical arrow check
                            special_gens.append(disk[0][0][0])
        
            current_gens = []
            for parent in parents: current_gens.append(parent)
        
        return[arm,current_gens,used_gens,special_gens]
        
    if  startindex == 2: #checks generators with same grading as S3 for additional horizonal arrows, starting with children (for left-arm)
        current_gens = specialgens
        while keep_going:
            keep_going = False
            children = []
            for current_gen in current_gens: #find children of current (for the special generators that lie at S3 gradings), add disks to new complex
                for disk in disks:
                    if disk[0][0][0] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm: #tail of horiz arrow, make sure it is in horizontal part of arm
                        arm.append(disk)
                        used_gens.append(disk[0][0][1])
                        children.append(disk[0][0][1])
                        if hor_gradings[disk[0][0][1] - 1][1] == hor_gradings[S3_gen - 1][1]: #adds generators that have same grading as S3_gen
                            special_gens.append(disk[0][0][1])
                        
            current_gens = []
            for child in children: current_gens.append(child)
                        
            parents = []
            for current_gen in current_gens: #find parents of current (for the speical generators that lie at the S3 gradings), add disks to new complex
                for disk in disks:           
                    if disk[0][0][1] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm and hor_gradings[disk[0][0][0] - 1][1] <= hor_gradings[S3_gen - 1][1]:  #head of horiz arrow, makes sure it still lies in left arm
                        keep_going = True #Were there parents? Cycle through again
                        arm.append(disk)
                        used_gens.append(disk[0][0][0])
                        parents.append(disk[0][0][0])
                        if hor_gradings[disk[0][0][0] -1][1] == hor_gradings[S3_gen -1][1]: 
                            special_gens.append(disk[0][0][0])
        
            current_gens = []
            for parent in parents: current_gens.append(parent)
        
        return[arm,current_gens,used_gens,special_gens]
    
    if startindex == 3: #finds all horizontal arrows for the right arm complex, starts with parents 
        current_gens = currentgens
        while keep_going:
            keep_going = False
            parents = []
            for current_gen in current_gens: #find parents of current, add disks to new complex
                for disk in disks:           
                    if disk[0][0][1] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm :  #head of horiz arrow for right arm complex
                        #keep_going = True #Were there parents? Cycle through again
                        arm.append(disk)
                        used_gens.append(disk[0][0][0])
                        parents.append(disk[0][0][0])
                        if hor_gradings[disk[0][0][0] -1][1] == hor_gradings[S3_gen -1][1]: 
                            special_gens.append(disk[0][0][0])
        
            current_gens = []
            for parent in parents: current_gens.append(parent)
            
            children = []
            for current_gen in current_gens: #find children of current, add disks to new complex
                for disk in disks:
                    if disk[0][0][0] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm and hor_gradings[disk[0][0][0] - 1][1] >= hor_gradings[S3_gen - 1][1]: #tail of horiz arrow, make sure it still lies in right arm
                        keep_going = True #were there children?? Cycle through again 
                        arm.append(disk)
                        used_gens.append(disk[0][0][1])
                        children.append(disk[0][0][1])
                        if hor_gradings[disk[0][0][1] - 1][1] == hor_gradings[S3_gen - 1][1]: #adds generators that have same grading as S3_gen for vertical arrow check
                            special_gens.append(disk[0][0][1])
                        
            current_gens = []
            for child in children: current_gens.append(child)
            
        return[arm,current_gens,used_gens,special_gens]
    
    if startindex == 4: #checks generators with same grading as S3 generator for additional horizonatl arrow, starts with parents for right arm complex
        current_gens = specialgens
        while keep_going:
            keep_going = False
            parents = []
            for current_gen in current_gens: #find parents of current, add disks to new complex
                for disk in disks:           
                    if disk[0][0][1] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm:  #head of horiz arrow for right arm complex
                        #keep_going = True #Were there parents? Cycle through again
                        arm.append(disk)
                        used_gens.append(disk[0][0][0])
                        parents.append(disk[0][0][0])
                        if hor_gradings[disk[0][0][0] -1][1] == hor_gradings[S3_gen -1][1]: 
                            special_gens.append(disk[0][0][0])
        
            current_gens = []
            for parent in parents: current_gens.append(parent)
            
            children = []
            for current_gen in current_gens: #find children of current, add disks to new complex
                for disk in disks:
                    if disk[0][0][0] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in arm and hor_gradings[disk[0][0][0] - 1][1] >= hor_gradings[S3_gen - 1][1]: #tail of horiz arrow, make sure it still lies in right arm complex
                        keep_going = True #were there children?? Cycle through again 
                        arm.append(disk)
                        used_gens.append(disk[0][0][1])
                        children.append(disk[0][0][1])
                        if hor_gradings[disk[0][0][1] - 1][1] == hor_gradings[S3_gen - 1][1]: #adds generators that have same grading as S3_gen for vertical arrow check
                            special_gens.append(disk[0][0][1])
                        
            current_gens = []
            for child in children: current_gens.append(child)
            
        return[arm,current_gens,used_gens,special_gens]
        
def vertical_arm(C,G_vert,S3_gen,arm_complex,currentgens,usedgens,specialgens,startindex): #finds vertical arrows for arm complex 
    
    disks = C 
    vert_gradings = G_vert
    #current_gens = specialgens
    used_gens = usedgens
    keep_going = True
    arm = arm_complex
    special_gens = specialgens #will include generators that have same grading as S3_gen, could have additional horizontal arrows
    
    if startindex == 1: #checks generators that have same grading as S3 generator for horizontal arrow, starts with children for left-arm complex
        current_gens = specialgens
        while keep_going:
            keep_going = False
            children = []
            for current_gen in current_gens: #find children of current, add disks to new complex
                for disk in disks:
                    if disk[0][0][0] == current_gen and disk[1] != 0 and disk[2] == 0 and disk not in arm: #tail of horiz arrow, make sure it is in horizontal part of arm
                        arm.append(disk)
                        used_gens.append(disk[0][0][1])
                        children.append(disk[0][0][1])
                        if vert_gradings[disk[0][0][1] - 1][2] == vert_gradings[S3_gen - 1][2]: #adds generators that have same grading as S3_gen
                            special_gens.append(disk[0][0][1])
                        
            current_gens = []
            for child in children: current_gens.append(child)
        
            parents = []
            for current_gen in current_gens: #find parents of current, add disks to new complex
                for disk in disks:           
                    if disk[0][0][1] == current_gen and disk[1] != 0 and disk[2] == 0 and disk not in arm and vert_gradings[disk[0][0][0] - 1][2] <= vert_gradings[S3_gen - 1][2]:  #head of horiz arrow, makes sure it still lies in left arm complex
                        keep_going = True #Were there parents? Cycle through again
                        arm.append(disk)
                        used_gens.append(disk[0][0][0])
                        parents.append(disk[0][0][0])
                        if vert_gradings[disk[0][0][0] -1][2] == vert_gradings[S3_gen -1][2]: #adds generators that have same grading as S3_gen
                            special_gens.append(disk[0][0][0])
        
            current_gens = []
            for parent in parents: current_gens.append(parent)
            
        return[arm,current_gens,used_gens,special_gens]
    
    if startindex == 2: #check generators that have same grading as S3 generator for horizontal arrows, starts with parents for right-arm complex
        current_gens = specialgens
        while keep_going: 
            keep_going = False 
            parents = []
            for current_gen in current_gens: #find parents of current, add disks to new complex
                for disk in disks:           
                    if disk[0][0][1] == current_gen and disk[1] != 0 and disk[2] == 0 and disk not in arm and vert_gradings[disk[0][0][0] - 1][2] >= vert_gradings[S3_gen - 1][2]:  #head of horiz arrow, makes sure it still lies in left arm complex
                        #keep_going = True #Were there parents? Cycle through again
                        arm.append(disk)
                        used_gens.append(disk[0][0][0])
                        parents.append(disk[0][0][0])
                        if vert_gradings[disk[0][0][0] -1][2] == vert_gradings[S3_gen -1][2]: #adds generators that have same grading as S3_gen
                            special_gens.append(disk[0][0][0])
                            
            children = []
            for current_gen in current_gens: #find children of current, add disks to new complex
                for disk in disks:
                    if disk[0][0][0] == current_gen and disk[1] != 0 and disk[2] == 0 and disk not in arm and vert_gradings[disk[0][0][1] -1][2] >= vert_gradings[S3_gen - 1][2]: #tail of horiz arrow, make sure it is in horizontal part of arm
                        keep_going = True #were there children? Cycle through again
                        arm.append(disk)
                        used_gens.append(disk[0][0][1])
                        children.append(disk[0][0][1])
                        if vert_gradings[disk[0][0][1] - 1][2] == vert_gradings[S3_gen - 1][2]: #adds generators that have same grading as S3_gen
                            special_gens.append(disk[0][0][1])
                        
            current_gens = []
            for child in children: current_gens.append(child)
            
        return[arm,current_gens,used_gens,special_gens]
            
def calc_Epsilon(left_arm_v, right_arm_v):
    v = left_arm_v
    vprime = right_arm_v
    epsilon = "Epsilon Error"
    
    if v and vprime: 
        epsilon = 0 
    
    if not v and vprime: 
        epsilon = -1 
    
    if v and not vprime: 
        epsilon = 1
        
    return epsilon

def homology_survives(special_gen, C, G, side):
    quiver = []
    arrow_was_contracted = True
    #Add special pointer to identified gen
    if side == 0: C.append([[(0, special_gen)], 0, 0])
    if side == 1: C.append([[(special_gen, 0)], 0, 0])
    
    #Any disk with a tail at 0 will need to be ignored
    while arrow_was_contracted: #contract arrows
        arrow_was_contracted = False
        for arrow in C:
            if arrow[0][0][0] != 0 and arrow[0][0][1] != 0  and arrow not in quiver: 
                quiver.append(arrow)
               
                #print("Contracting: ", arrow)
                C = contract_and_remove(arrow, C)
               # print("Left with: ", C)
                #print("\n")
                arrow_was_contracted = True
                break
            
        if not arrow_was_contracted: 
            
            #check if isolated          
            for gen in G:
                is_pointer_isolated = True
                for disk in C: 
                    if disk[0][0][0] == 0 or disk[0][0][1] == 0: is_pointer_isolated = False 
                if is_pointer_isolated:
                    #print("returning F")
                    return False
                
    #print("returning T")
    return True

"""
===========================================
Contraction Algs
===========================================

"""

def contract_and_remove(arrow, C):
    new_complex = []
    for a in C: #cut out grading info, its not doubly graded anymore
        if a[0] not in new_complex:
            new_complex.append(a[0])
        else: new_complex.remove(a[0])
    
    #Identify Head and Tail
    head = arrow[0][0][1]
    tail = arrow[0][0][0] 
    
    #Get Parents of head
    parents = []
    children = []
    temp = []
    
    #print(new_complex)
    
    for disk in new_complex:
        if disk[0][1] == head: #throw out arrows into head, collect parents
            parents.append(disk[0][0])
            temp.append(disk)
        if disk[0][0] == head: #throw out arrows leaving head
            temp.append(disk)
    #print(parents)
    #Get Children of tail
    
    for disk in new_complex:
        if disk[0][0] == tail and disk[0][1] != head: #throw out arrows leaving tail, collect child, already got one arrow
            children.append(disk[0][1])
            temp.append(disk)
        if disk[0][1] == tail: #throw out arrows into tail
            temp.append(disk)
    #print(children)
    #cleanup by throwing out the arrows. But FIRST we should have calculated new disks.
    
    for parent in parents:
        for child in children:                    
            new_arrow = ([(parent, child)])
            if new_arrow in new_complex: #add mod2
                new_complex.remove(new_arrow)
            else: new_complex.append(new_arrow)                
    
    #Actual cleanup
    for disk in temp: 
        if disk in new_complex: new_complex.remove(disk)  
    outp = []    
    for disk in new_complex:
        outp.append((disk, 0, 0))
    
    return outp


"""
def cps(complex):
    - Search for orphans
    - Search for single parent children
    -remove them from the complex
"""

"""
===========================================
find_Upsilon
===========================================
In: complex(C,G)
Out: list of pairs of pairs [...,[[t_n, t_d],[u_n, u_d],...]
 
Should take a complex, and return (potentially) critical points of the upsilon function
as rational numbers encoded as pairs,i.e. [[t_n, t_d],[u_n, u_d] encodes (t_n/t_d,upsilon(t_n/t_d)).
Todo: Clean output so only critical points are returned; decide whether to output a graph
"""       
#make_Small function:
#Take as input a list of bifiltered,
#homologically relatively graded complex with generators
#x_k[i,j] = [k,i,j,relative hom/Maslov grading] "Graded Coords"
#and arrows x_k[i_k,j_k] --> x_l[i_l,j_l] 
#= ([(k,l)],i_k-i_l,j_k-j_l) "Complex"
#Returns the Maslov 0 and Malov 1 translates of each generator; keeps
#track of which indices are grading zero/even
def make_Small(a_complex, gcoords):

    pgen = []
    plist = []
    zgen = []
    zlist = []
    #ngen = []
    for gen in gcoords:
        evod = gen[3] % 2
        if evod == 0:
            newgen = [gen[0], gen[1]-int(.5*gen[3]), gen[2]-int(.5*gen[3]), 0]
            zgen.append(newgen)
            zlist.append(newgen[0])
        else:
            newgen = [gen[0], gen[1]-int(.5*(gen[3]-1)), gen[2]-int(.5*(gen[3]-1)), 1]
            pgen.append(newgen)
            plist.append(gen[0])
            #newgen = [gen[0], gen[1]-int(.5*(gen[3]+1)), gen[2]-int(.5*(gen[3]+1)), -1]
            #ngen.append(newgen)
    small_gens = pgen + zgen #+ ngen

    return[a_complex, small_gens,zlist]


#Output a list of candidate slopes between generators in grading zero
def ups_slopes(gcoords):

    bigrad_list = []
    intslope_list = []
    #Always check slope -1
    intslope_list.append(tuple([-1,1]))

    for gen in gcoords:
        if gen[3] == 0:
            bigrad = [gen[1],gen[2]]
            bigrad_list.append(bigrad)
    #Only need to add finite slope less than -1
    for coord in list(itertools.combinations(bigrad_list,2)):
        #print(coord)
        intslope = [coord[1][1]-coord[0][1],coord[1][0]-coord[0][0]]
        #print(intslope)
        if intslope[0]*intslope[1] < 0 and abs(intslope[0]) > abs(intslope[1]):
            #print([intslope[0],intslope[1]])
            gcdiv = math.gcd(intslope[0],intslope[1])
            if intslope[0] < 0:
                    intslope = [int(intslope[0]/gcdiv),int(intslope[1]/gcdiv)]
            else:
                intslope = [-int(intslope[0]/gcdiv),-int(intslope[1]/gcdiv)]
            intslope_list.append(tuple(intslope))
    #Remove duplicates            
    intslope_list = list(dict.fromkeys(intslope_list))   
    #print(intslope_list)     
    return(intslope_list)


#Takes a Maslov graded complex, and returns the geometrically
#graded complex associated to a particular slope
#and the conversion factor to t-grading

def upsilon_Geom_Grad(a_complex, gcoords, slope):
    scale_factor = abs(slope[1]) + abs(slope[0])
    geom_coords = []
    slope_complex =[]
    for gen in gcoords:
        #Check format for arrow contraction algorithm
        newgen = [gen[0],0,gen[1]*abs(slope[1]) + gen[2]*abs(slope[0]), gen[3]]
        geom_coords.append(newgen)

    for arrow in a_complex:
        newarrow = [arrow[0],arrow[2]*abs(slope[1]) + arrow[1]*abs(slope[0]),0]
#        for coord in geom_coords:
#            if arrow[0][0][1] == coord[0]:
#                head_grad = coord[2]
#            elif arrow[0][0][0] == coord[0]:
#                tail_grad = coord[2]
#        newarrow = [arrow[0],  tail_grad - head_grad,0]
        slope_complex.append(newarrow)

    return[slope_complex, geom_coords, scale_factor]



#Modified robust_Calc_S3 which only checks indices of preferred generators
#(used to compute tau for each slope; only checks in Maslov grading zero)
def pref_Calc_S3(hat_complex, hat_coords, zero_gen): #zero_gen is a list containing indices of generators in Maslov grading zero
    contracted_complex = copy.deepcopy(hat_complex) #We want to preserve the original hat complex
    quiver = []
    length = 1
    S3_gen = 0
    while S3_gen == 0:
        arrow_was_contracted = False

        #grab a length i arrow
        for arrow in contracted_complex:
            if arrow[1] == length and arrow not in quiver: #use coords of form [index, 0, j, maslov]
                quiver.append(arrow)
                contracted_complex = contract(arrow, contracted_complex, hat_coords)[0]
                arrow_was_contracted = True
                break

        if not arrow_was_contracted: 
            length += 1
            #check if done          
            for gen in zero_gen: #Only check Maslov grading zero
                is_isolated = True
                for disk in contracted_complex: 
                    if disk[0][0][0] == gen or disk[0][0][1] == gen: is_isolated = False 
                if is_isolated: 
                    S3_gen = gen
                    break

        if length > 1000: sys.exit("I'ma keep on runnin' (arrow length exceeded 1000, if for some reason this is not unreasonable get rid of this sys.exit line)")

    return S3_gen

def robust_Get_Tau(S3_gen, hat_gradings):
    for gen in hat_gradings:
        if gen[0] == S3_gen:
            tau = gen[2]
            break
    return tau

#Computes Upsilon for a Maslov graded complex with preferred (grading zero) generators
def ups_Calc(a_complex, gcoords,zero_gen):

    slopes = ups_slopes(gcoords)
    ups_coord = []

    for slope in slopes:
        c_data = upsilon_Geom_Grad(a_complex, gcoords, slope)
        c_complex = c_data[0]
        c_coords = c_data[1]
        scale_factor = c_data[2]

        geom_gamma = robust_Get_Tau(pref_Calc_S3(c_complex,c_coords,zero_gen), c_coords)
        ups_gcd = math.gcd(-2*geom_gamma,scale_factor)
        ups_value = [int(-2*geom_gamma/ups_gcd), int(scale_factor/ups_gcd)]
        tee_gcd = math.gcd(2*slope[1], slope[1]-slope[0])
        tee = [int(2*slope[1]/ tee_gcd), int((slope[1]-slope[0])/ tee_gcd)] #t = 2/(1-slope)

        ups_coord.append([tee,ups_value])


    #add some lines to eliminate redundant values and print as fractions
    #add some lines to find arbitrary upsilon values

    return ups_coord

#Returns Upsilon for an appropriate bigraded complex
def find_Upsilon(a_complex,coords):
    gdata = make_Maslov(a_complex,coords)
    smalldata = make_Small(gdata[0],gdata[1])
    upsilon = ups_Calc(smalldata[0], smalldata[1],smalldata[2])
    return(upsilon)


"""
===========================================================
Helper Functions
===========================================================
"""
    
def gen_Complex(T): #Requires a 4-Tuple
    C = calc_Complex(T)
    return [C, calc_Gradings(C, T)]

def calc_Complex(T): #Requires a 4-tuple
    return fti.reduce_Generators(fti.diskfinder(fti.find_Fundamental_Domains(fti.fourtuple(T[0], T[1], T[2], T[3]),T),T),T)

def calc_Hat(C, G): #requires a complex and its calculated gradings
    return make_Hat(C, G)

def calc_Gradings(C, T): #requires a complex and the 4-Tuple
    return find_Coords(C, T)

def get_A_Grading(gen, G):#requires a generator and a grading set
    return G[gen-1][2]

def get_Tau(S3_gen, hat_gradings): #Requires s3 generator and gradings of hat complex
    return hat_gradings[S3_gen - 1][2]

def make_Vert(C, G):
    temp = calc_Hat(C, G)
    return [C, temp[1]]

def gen_AGraded_Complex(T):
    C = gen_Complex(T)
    return make_Vert(C[0], C[1])

