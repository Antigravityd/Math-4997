# -*- coding: utf-8 -*-
"""
Created on Sun Mar  7 18:11:09 2021

@author: Nurdin Takenov
"""

#Exaplanation for program
#This program generates staircase-like complex for testing Upsilon invarinat
#We generate complexes symmetric with respect to diagonal line i=j
#Since the complex is diagonal, it is enough to give the sequence of horizontal steps
#The vertical steps will be given by the list of horizontal steps read backwards
#To generate the staircase two number should be given: size n and number k
#size n tells us the size of a staircase, namely horizontal=vertical dimension of a staircase
#number k tells which particular staircase of size n we are generating
#this is how it works, for any staircase of size n, the sequence of
#horizontal steps forms an ordered partition(combination) of n.
#for a given n there are 2^(n-1) combinations of n. For example, 
#if n=3 we have the following combinations: 3, 2+1, 1+2, 1+1+1
#Therefore we can enumerate all the combination of n using numbers from 0 to 
#2^(n-1)-1 . That is what k for.
#we have two commands: combination and staircase.
#combination(n,k) is an auxiliary function and generates k-th combination of n.
#staircase(n,k) generates complex corresponding to combination(n,k) 

#creates number-th combination of size size. For example combination(4,6)
#returns 6-th combination of 4
# 0<= number <2**(size -1)

def combination(size, number):
    if(number>=2**(size-1)):
        print('Size is too large')
    n=size-1
    k=number
    list=[]
    ktemp=k
    #converts number into list of binary digits of length (size -1)
    for i in range(n):
        list.append(ktemp%2)
        ktemp = ktemp//2
    #print(list)
    #converts list of binary digits into combination
    comb=[]
    ktemp=1
    for i in range(n):
        if list[i]==1:
            comb.append(ktemp)
            ktemp=1
        else:
            ktemp=ktemp+1
    comb.append(ktemp)
    #print(comb)
    return comb

#creates staircase complex corresponding to number-th combination of size size
## 0<= number <2**(size -1)

def stairup(size, number):
    n=size
    comb = combination(size, number)
    k=len(comb)
    #print(n,k,comb)
    #generated complex
    stair = []
    stair0 = []
    stair1 = []
    for i in range(k):
        stair0.append(([(2*i+2,2*i+1)],0,comb[i]))
        stair0.append(([(2*i+2,2*i+3)],comb[k-1-i],0))
    #print(stair0)
    xcor = 0
    ycor = size
    stair1.append([1,xcor,ycor])
    for i in range(k):
        xcor = xcor+comb[i]
        stair1.append([2*i+2,xcor,ycor])
        ycor = ycor - comb[k-1-i]
        stair1.append([2*i+3,xcor,ycor])
    #print(stair1)
    stair.append(stair0)
    stair.append(stair1)
    return stair

def stairdown(size, number):
    n=size
    comb = combination(size, number)
    k=len(comb)
    #print(n,k,comb)
    #generated complex
    stair = []
    stair0 = []
    stair1 = []
    for i in range(k):
        stair0.append(([(2*i+1,2*i+2)],comb[k-1-i],0))
        stair0.append(([(2*i+3,2*i+2)],0,comb[i]))
    #print(stair0)
    xcor = 0
    ycor = size
    stair1.append([1,xcor,ycor])
    for i in range(k):
        ycor = ycor - comb[k-1-i]
        stair1.append([2*i+2,xcor,ycor])
        xcor = xcor+comb[i]
        stair1.append([2*i+3,xcor,ycor])
    #print(stair1)
    stair.append(stair0)
    stair.append(stair1)
    return stair

def thinup(size):
    n=size
    comb=[]
    for i in range(n):
        comb.append(1)
    #print(n,k,comb)
    #generated complex
    stair = []
    stair0 = []
    stair1 = []
    for i in range(n):
        stair0.append(([(2*i+2,2*i+1)],0,comb[i]))
        stair0.append(([(2*i+2,2*i+3)],comb[n-1-i],0))
    #print(stair0)
    xcor = 0
    ycor = size
    stair1.append([1,xcor,ycor])
    for i in range(n):
        xcor = xcor+comb[i]
        stair1.append([2*i+2,xcor,ycor])
        ycor = ycor - comb[n-1-i]
        stair1.append([2*i+3,xcor,ycor])
    #print(stair1)
    stair.append(stair0)
    stair.append(stair1)
    return stair


def thindown(size):
    n=size
    stair = []
    stair0 = []
    stair1 = []
    for i in range(n):
        stair0.append(([(2*i+1,2*i+2)],1,0))
        stair0.append(([(2*i+3,2*i+2)],0,1))
    #print(stair0)
    xcor = 0
    ycor = size
    stair1.append([1,xcor,ycor])
    for i in range(n):
        ycor = ycor - 1
        stair1.append([2*i+2,xcor,ycor])
        xcor = xcor+1
        stair1.append([2*i+3,xcor,ycor])
    #print(stair1)
    stair.append(stair0)
    stair.append(stair1)
    return stair



        
    
