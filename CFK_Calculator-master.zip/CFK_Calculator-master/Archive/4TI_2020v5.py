# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 14:15:41 2019

@author: Rob Quarles
@author: zjermain15
"""

#import numpy as np 
import sys
import sympy as sym
import copy

"""
Helper_Functions
"""
def lMod(number,n):
    if number == 0: number = n
    while number > n:
        number = number - n
    return number

#print(lMod(9,7)) = 2 as expected

def rMod(number, n):
    return lMod(number,n) + n
    
#print(rMod(15,7)) = 8 as expected

"""
input_Function
-> Should take input and call proper functions to calc invars

"""



"""
interpret_4tuple

In: 4-tuple (w,x,y,z)
Out: list of lists [[x_1, y_1],...,[x_n, y_n]]
 
Should interpret a given 4-tuple, determine if it is a (1,1)-knot, and return
a list of \beta arcs given as a Vector2 (start and end mark on diagram)
"""


def fourtuple(p,a,b,r):
    #check if four-tuple satifies algebraic restrictions
    if p%2 == 0:
        sys.exit("p is not odd. Invalid 4-tuple diagram")
       
    if a > p/2:
        sys.exit("a > p/2. Invalid 4-tuple diagram")
   
    if a < 1 or r < 1 or a > p or r > p:
        sys.exit("Invalid 4-tuple diagram")
       
    if b < 0 or b > (p-2*a):
        sys.exit("Invalid 4-tuple diagram")
    if 2*a + b + r < p:
        sys.exit("Invalid 4-tuple diagram")

    lines = []
    c = p -2*a - b
    #counts lines for small discs around w and z base points
    for i in range(a):
        lines.append((i+1,2*a-i)) #adds lines from left discs
        x = p + r + b + i#gives first intersection point for right discs
        if x > 2*p :        #checks if disc goes below one fundamental region
            x = x%(2*p) + p
        y = p + r + b + 2*a - i -1 #gives second interseciton point for right discs
        if y > 2*p:         #checks if disc goes below one fundamental region
            y = y %(2*p) + p
        lines.append((x,y))  #adds lines from right discs
    #adds b arcs
    for j in range(b):
        lines.append((lMod(2*a+1+j, p),rMod(p+r+j, p))) #Now accounts for wrap around
   
   
    #adds arcs below base points
    for k in range(c):
        x = 2*p - c + r + k
        if x > 2*p:
            x = x%(2*p) + p
        lines.append((p-c+1+k,x))
       
    beta = [] #new list to check for a closed beta arc
    beta.append(lines[0]) #adds first arc to beta
    permutation = [] #list to check for permutation of all intersection points and crossing number
    permutation.append((lines[0][0],1)) #adds first point and appropriate crossing number
    permutation.append((lines[0][1],-1))
    n = 0 # counter for beta index
    l = 0 #counter for beta loop check
    #print(lines)
    #print(len(lines))
    while l < len(lines) -1: # runs for all curves in 4 tuple to check one closed beta curve
        while n == 0: #connects the first arc to the starting arc (makes sure starting arc is not repeated)
            for m in range(1,len(lines)):
                if beta[n][1] % p == lines[m][0] % p: #finds the arc which starts at the endpoint of the first arc
                    beta.append((lines[m])) #adds arc to beta list
                    permutation.append((lines[m][0],1)) #adds first point, with crossing number
                    permutation.append((lines[m][1],-1)) #adds second point, with crossing number
                    n+=1 #proceeds to next beta index
                    l+=1 #procees in loop
                elif (beta[n][1] % p == lines [m][1] % p):
                   beta.append((lines[m][1],lines[m][0])) #adds arc, and switches order of points to corrctly define curve
                   permutation.append((lines[m][1],1)) #adds point with crossing number
                   permutation.append((lines[m][0],-1)) #adds point with crossing number
                   n+= 1
                   l+= 1  
        for m in range(len(lines)): #attempts to connect all remaining arcs to find one closed beta curve
            #while l < len(lines) -1:
                if beta[n][1] % p == lines[m][0] % p: #finds arc which starts at the endpoint of current arc
                    if len(beta) > len(lines) -1 :
                        break
                    beta.append((lines[m]))
                    permutation.append((lines[m][0],1))
                    permutation.append((lines[m][1],-1))
                    n += 1
                    l += 1
                elif beta[n][1] % p == lines[m][1] % p:
                    if len(beta) > len(lines) -1:
                        break
                    beta.append((lines[m][1],lines[m][0]))
                    permutation.append((lines[m][1],1))
                    permutation.append((lines[m][0],-1))
                    n += 1
                    l += 1
                if beta[n] == beta[0]: #checks that beta defines one closed curve, no repeats
                    sys.exit("Beta does not define one closed curve. You have reached the starting point before hitting all generators")
   
    #print(beta)
    #print(len(beta))
    for q in range(1,len(lines)):#checks if beta defines one closed curve
        if beta[q] == beta[0] or (beta[q][1],beta[q][0]) == beta[0]:
            sys.exit("Beta does not define one closed curve")
    if (beta[p-1][1]) % p  != beta[0][0] % p:
        sys.exit("Beta does not define one closed curve. Curve doesn't end at starting point")
   
    i = 0
    leftcross = 0
    rightcross = 0
    for i in range(2*len(lines)): #calculates crossing number for each side
        if permutation[i][0] <= p:
            leftcross += permutation[i][1]
        if permutation[i][0] > p:
            rightcross += permutation[i][1]
    if debug[0]: print(leftcross)
    if debug[0]: print(rightcross)
    if leftcross == 1 or leftcross == -1: #checks if crossing number for left side is +-1
        if debug[0]: print("Crossing number for left side is correct")
    elif leftcross != 1 or leftcross != -1:
        sys.exit("Crossing number for left side is not 1 or -1")
    if rightcross == 1 or rightcross == -1: #checks if crossing number for right side is +-1
        if debug[0]: print("Crossing number for right side is correct")
    elif rightcross != 1 or rightcross != -1:
        sys.exit("Crossing number for right side is not 1 or -1")
           
       
           
     
   
    #print(beta)
    #print(len(permutation))
    #print(permutation[0])
    #print(permutation[1])
    if debug == [True]: print (beta)
    return beta

#test_arcs = [(1,4),(11,14),(7,9),(2,3),(10,5),(12,13),(6,8)]
def fourtuple_Loop(p,a,b,r):
    #check if four-tuple satifies algebraic restrictions
    if p%2 == 0:
        return [True]
       
    if a > p/2:
        return [True]
   
    if a < 1 or r < 1 or a > p or r > p:
        return [True]
       
    if b < 0 or b > (p-2*a):
        return [True]
    if 2*a + b + r < p:
        return [True]

    lines = []
    c = p -2*a - b
    #counts lines for small discs around w and z base points
    for i in range(a):
        lines.append((i+1,2*a-i)) #adds lines from left discs
        x = p + r + b + i#gives first intersection point for right discs
        if x > 2*p :        #checks if disc goes below one fundamental region
            x = x%(2*p) + p
        y = p + r + b + 2*a - i -1 #gives second interseciton point for right discs
        if y > 2*p:         #checks if disc goes below one fundamental region
            y = y %(2*p) + p
        lines.append((x,y))  #adds lines from right discs
    #adds b arcs
    for j in range(b):
        lines.append((lMod(2*a+1+j, p),rMod(p+r+j, p)))
   
   
    #adds arcs below base points
    for k in range(c):
        x = 2*p - c + r + k
        if x > 2*p:
            x = x%(2*p) + p
       
        lines.append((p-c+1+k,x))
       
    beta = [] #new list to check for a closed beta arc
    beta.append(lines[0]) #adds first arc to beta
    permutation = [] #list to check for permutation of all intersection points and crossing number
    permutation.append((lines[0][0],1)) #adds first point and appropriate crossing number
    permutation.append((lines[0][1],-1))
    n = 0 # counter for beta index
    l = 0 #counter for beta loop check
    #print(lines)
    #print(len(lines))
    while l < len(lines) -1: # runs for all curves in 4 tuple to check one closed beta curve
        while n == 0: #connects the first arc to the starting arc (makes sure starting arc is not repeated)
            for m in range(1,len(lines)):
                if beta[n][1] % p == lines[m][0] % p: #finds the arc which starts at the endpoint of the first arc
                    beta.append((lines[m])) #adds arc to beta list
                    permutation.append((lines[m][0],1)) #adds first point, with crossing number
                    permutation.append((lines[m][1],-1)) #adds second point, with crossing number
                    n+=1 #proceeds to next beta index
                    l+=1 #procees in loop
                elif (beta[n][1] % p == lines [m][1] % p):
                   beta.append((lines[m][1],lines[m][0])) #adds arc, and switches order of points to corrctly define curve
                   permutation.append((lines[m][1],1)) #adds point with crossing number
                   permutation.append((lines[m][0],-1)) #adds point with crossing number
                   n+= 1
                   l+= 1  
        for m in range(len(lines)): #attempts to connect all remaining arcs to find one closed beta curve
            #while l < len(lines) -1:
                if beta[n][1] % p == lines[m][0] % p: #finds arc which starts at the endpoint of current arc
                    if len(beta) > len(lines) -1 :
                        break
                    beta.append((lines[m]))
                    permutation.append((lines[m][0],1))
                    permutation.append((lines[m][1],-1))
                    n += 1
                    l += 1
                elif beta[n][1] % p == lines[m][1] % p:
                    if len(beta) > len(lines) -1:
                        break
                    beta.append((lines[m][1],lines[m][0]))
                    permutation.append((lines[m][1],1))
                    permutation.append((lines[m][0],-1))
                    n += 1
                    l += 1
                if beta[n] == beta[0]: #checks that beta defines one closed curve, no repeats
                    return [True]
   
    #print(beta)
    #print(len(beta))
    for q in range(1,len(lines)):#checks if beta defines one closed curve
        if beta[q] == beta[0] or (beta[q][1],beta[q][0]) == beta[0]:
            return [True]
    if (beta[p-1][1]) % p  != beta[0][0] % p:
        return [True]
   
    i = 0
    leftcross = 0
    rightcross = 0
    for i in range(2*len(lines)): #calculates crossing number for each side
        if permutation[i][0] <= p:
            leftcross += permutation[i][1]
        if permutation[i][0] > p:
            rightcross += permutation[i][1]
    if debug[0]: print(leftcross)
    if debug[0]: print(rightcross)
    if leftcross == 1 or leftcross == -1: #checks if crossing number for left side is +-1
        if debug[0]: print("Crossing number for left side is correct")
    elif leftcross != 1 or leftcross != -1:
        return [True]
    if rightcross == 1 or rightcross == -1: #checks if crossing number for right side is +-1
        if debug[0]: print("Crossing number for right side is correct")
    elif rightcross != 1 or rightcross != -1:
        return [True]
    
    return [False, beta]

"""
find_Regions

In: list of lists [[x_1, y_1],...,[x_n, y_n]]
Out: list of lists [[[boundary arcs] nz, nw], ... ]

Eats a list of lines defining the \beta arcs and return a lsit of small
regions [gen 1, gen 2, z multiplicity, w multiplicity]
"""

def find_Regions(arcs, f_tuple): 
    #Get length of list:
    n = f_tuple[0]
    
    #create master list of gluing arcs
    g_arcs = []
    small_regions = []
    
    #generate master list of gluing arcs (left side)
    for zero_index in range(0,n):
        
        #fix indexing issues
        i = zero_index + 1
        
        #populuate the master list of gluing arcs
        g_arcs.append((i,lMod(i+1,n)))
        #g_arcs.append((i,lMod(i-1,n)))

    #generate master list of gluing arcs (right side)
    for zero_index in range(0,n):
        
        #fix indexing issues
        i = zero_index + 1 + n
        
        #populuate the master list of gluing arcs
        g_arcs.append((i,rMod(i+1,n)))
        #g_arcs.append((i,rMod(i-1,n)))
    
    #print (g_arcs)
    #generate small regions by picking directed paths out of the master list
    #and using the guide of the arcs
    for zero_index in range(0,2*n):
        #fix indexing issues
        i = zero_index + 1
        pos = i
        start_pos = i
        
        #keeps track of if we are on the RHS after starting on the LHS
        changed_sides = False #our first check will not change sides by construction

        temp_region = []
        unfinished_region = True
        
        while unfinished_region:
            
            if changed_sides == False: #we havent switched sides yet
                for arc in g_arcs:
                    
                    #if your position matches that of a gluing arc
                    if arc[0] == pos:
                        
   
                        pos = arc[1] #move to other endpoint (DOWN)
                        
                        #add the gluing arc to your small region
                        temp_region.append(arc)
                        
                        #change position based on the paths in the diagram
                        for path in arcs:
                            
                            if path[0] == pos:
                                pos = path[1]
                                #Did we switch to the RHS?
                                if path[0] <= n and path[1] > n: changed_sides = True
                                break
                            elif path[1] == pos:
                                pos = path[0]
                                #Did we switch to the RHS?
                                if path[1] <= n and path[0] > n: changed_sides = True
                                break
                        #Remove the gluing arc from our master list; we dont want duplicates
                        g_arcs.remove((arc[0],arc[1]))
                        #g_arcs.remove((arc[1],arc[0]))
                            
                        break
                if pos == start_pos: unfinished_region = False
                
            else: #We have switched to the RHS
                for arc in g_arcs:
                    
                    #if your position matches that of a gluing arc
                    if arc[1] == pos:
                           
                        pos = arc[0] #move UP
                        
                        #add the gluing arc to your small region
                        temp_region.append(arc)
                        
                        #change position based on the paths in the diagram
                        for path in arcs:
                            
                            if path[0] == pos:
                                pos = path[1]
                                #Did we switch back to LHS?
                                if path[0] > n and path[1] <= n: changed_sides = False
                                break
                            elif path[1] == pos:
                                pos = path[0]
                                #Did we switch back to LHS?
                                if path[1] > n and path[0] <= n: changed_sides = False
                                break
                            
                        g_arcs.remove((arc[0],arc[1]))
                        #g_arcs.remove((arc[1],arc[0]))
                            
                        break
                if pos == start_pos: unfinished_region = False
            
        #Once the loop is done, add your small region    
        if temp_region != []: small_regions.append(temp_region)
        
        #Notes: By the time we finish cycling through the LHS, we have gotten
        #every small regions besides the "Small disks" on the RHS which will
        #be counted by the first part of the algorithm normally.
        
        #Now we just need to calculate basepoints, but there should only be
        #two! The size one small regions.
        regions_with_basepoints = []

        for region in small_regions:
            if len(region) == 1:
                if region[0][0] > n: #Add W basepoint
                   regions_with_basepoints.append([region, 0, 1])
                if region[0][0] < n: #Add Z basepoint
                   regions_with_basepoints.append([region, 1, 0]) 
            else: regions_with_basepoints.append([region, 0, 0]) 
    
    return regions_with_basepoints

"""
find_Fundamental_Domains

In: list of lists [[x_1, y_1],...,[x_n, y_n]]
Out: list of lists [[[boundary arcs on sides] nz, nw], ... ]

We want to calculate fundamentl regions in the 3 ways presented in the paper.
1. arcs above other arcs
2. disks cut out of disks
3. disks cut out of regions
"""

def find_Fundamental_Domains(arcs, f_tuple):
    #Get length of list:
    n = f_tuple[0]
    
    #create master list of fundamental domains defined by gluing arcs
    fds = []
    
    #sort arcs to start on LHS (keep disks same)
    sorted_arcs= []
    for arc in arcs:
        #If Cross diagram
        if (arc[0] <= n and arc[1] > n) or (arc[0] > n and arc[1] <= n):
            if arc[0] < arc[1] : sorted_arcs.append(arc) #Sorts arcs
            else: sorted_arcs.append((arc[1],arc[0]))
        
    #generate sorted disks.
    n_disks_on_side = f_tuple[1]
    for i in range(n_disks_on_side):
        sorted_arcs.append((1+i,2*n_disks_on_side - i)) #LHS
        sorted_arcs.append((rMod(f_tuple[0] + f_tuple[2] + f_tuple[3] + i,n) ,rMod(f_tuple[0] + f_tuple[3] + f_tuple[2] + 2*f_tuple[1] - i - 1,n)))
    
    #print(sorted_arcs)
    #index for arcs matches sorted_arcs
    
    #split sorted arcs into two groups: disks and not disks
    sorted_arcs_no_disks = []
    fundamental_disks = []
    #take out disks
    for arc in sorted_arcs:
        #This does indeed grab disks on RHS that wrap around.
        if (arc[0] <= n and arc[1] <= n) or (arc[0] > n and arc[1] > n):
            fundamental_disks.append(arc)
            if arc[0] <= n: #add disk with multiplicity to fds
                fds.append([[arc], 1, 0])
            else: fds.append([[arc], 0, 1])
        else: sorted_arcs_no_disks.append(arc)

    #Method one: Compare endpoints of arcs from one side of the diagram to the 
    #other
    
    used_arcs = []
    #Cycle through arcs
    for top_arc in sorted_arcs_no_disks: 
        
        #Make sure the arc starts on one side and ends on the other
        if (top_arc[0] <= n and top_arc[1] > n): #left to right
            
            for bot_arc in sorted_arcs_no_disks:
               
                if (top_arc != bot_arc) and (bot_arc not in used_arcs):                        
                    fds.append([[(top_arc[0], bot_arc[0]),(top_arc[1], bot_arc[1])], 0, 0])
                    fds.append([[(bot_arc[0], top_arc[0]),(bot_arc[1], top_arc[1])], 0, 0])
                    
        used_arcs.append(top_arc)
    if debug[0]: print("Small Disks: ")
    if debug[0]: print(fundamental_disks)
    if debug[0]: print("fds after first pass (above below): ")
    if debug[0]: print(fds)
    if debug[0]: print(len(fds))
    flag = False
    # ARC wrap around multiplicities:
    for i in range(len(fds)):
        if len(fds[i][0])> 1:
            if fds[i][0][0][0] > fds[i][0][0][1]: #wrap around LHS, add multiplicity
                fds[i][1] = 1
                
            #if fds[i][0][0][0] == 19 and fds[i][0][0][1] == 9 and fds[i][0][1][0] == 21 and fds[i][0][1][1] == 24: flag = True
            for disk in fundamental_disks: #compare to fund disks on RHS, add multiplicity
                if disk[0] > n: #disk on RHS
                    #g_arcs[1][0] < disk[0] < disk[1] < g_arcs[1][1]
                    if fds[i][0][1][0] < disk[0] < disk[1] < fds[i][0][1][1]: #disk inside gluing region
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 1st if statement in ARC WRAP")
                            print("Disk is: " , disk)
                            flag = False
                        break
                    
                    #g_arcs[1][1] < g_arcs[1][0] < disk[0] < disk[1]:
                    elif fds[i][0][1][1] < fds[i][0][1][0] < disk[0] < disk[1]:# Wrap/anchors above
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 2nd if statement in ARC WRAP")
                            flag = False
                        break
                    elif disk[0] < disk[1] < fds[i][0][1][1] < fds[i][0][1][0]:# Wrap/anchors below
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 3rd if statement in ARC WRAP")
                            flag = False
                        break
                    elif disk[1] < fds[i][0][1][1] < fds[i][0][1][0] < disk[0]:# anchors between/ disk wrap
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 4th if statement in ARC WRAP")
                            flag = False
                        break
            

    if debug[0]: print("fds after 2nd pass (wrap around multiplicities added): ")
    if debug[0]: print(fds)
    
    #Method 2: Take disks out of fds
    temp = []
 
    for fd in fds:
        if len(fd[0]) >1 : #its not a disk so continue
            lwrap = False
            flag = False
            g_arcs = fd[0]
            #if g_arcs[0] == (20,14): flag = True #Checking (9,10),(25,34),(20,25)
            
            #LHS need g_arc[0][0] > g_arc[0][1] i.e. wrap around
            if g_arcs[0][0] > g_arcs[0][1]: 
                lwrap = True
                for disk in fundamental_disks: #On LHS take out all the disks on LHS
                    if disk[0] <= n: #disks on LHS
                        temp.append([[(g_arcs[0][0],disk[0]),(disk[1],g_arcs[0][1]),g_arcs[1]], 0 , fd[2]])
           
            #We will cycle through disks to see if any can be taken out of the right.
            for disk in fundamental_disks: #compare to fund disks on RHS
                if disk[0] > n: #disk on RHS
                    if g_arcs[1][0] < disk[0] < disk[1] < g_arcs[1][1]:
                    #if (g_arcs[1][0] < disk[0] and g_arcs[1][1] > disk[1]) and g_arcs[1][1] > g_arcs[1][0] and disk[0] < disk[1]: #disk inside gluing region
                        temp.append([[g_arcs[0],(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], fd[1] , 0])
                        if flag: print("Case 1 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], 0 , 0])
                        
                    elif  g_arcs[1][1] < g_arcs[1][0] < disk[0] < disk[1]: #< disk[1]:# Wrap/anchors above
                    #elif g_arcs[1][0] > g_arcs[1][1] and g_arcs[1][0] < disk[0]:# Wrap/anchors above
                        temp.append([[g_arcs[0],(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], fd[1] , 0])
                        if flag: print("Case 2 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], 0 , 0])
                   
                    elif disk[0] < disk[1] < g_arcs[1][1] < g_arcs[1][0]:
                    #elif g_arcs[1][0] > g_arcs[1][1] and g_arcs[1][0] > disk[1]:# Wrap/anchors below
                        temp.append([[g_arcs[0],(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], fd[1] , 0])
                        if flag: print("Case 3 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], 0 , 0])
                    
                    elif disk[1] < g_arcs[1][1] < g_arcs[1][0] < disk[0]:
                    #elif g_arcs[1][0] > g_arcs[1][1] and (g_arcs[1][0] > disk[1] and g_arcs[1][1] < disk[0] and disk[0] > disk[1]):# anchors between/ disk wrap
                        temp.append([[g_arcs[0],(g_arcs[1][0], disk[0]),(disk[1],g_arcs[1][1])], fd[1] , 0])
                        if flag: print("Case 4 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][0], disk[0]),(disk[1],g_arcs[1][1])], 0 , 0])
                
       
    for t in temp:
        fds.append(t)
    
    if debug[0]: print("fds after third pass (cut out disks from regions): ")
    if debug[0]: print(fds)
    
    #Method 3: Disks from disks, (run last) (n,d,a,r)
    for j in range(f_tuple[1] - 1):
        for i in range(f_tuple[1]-1-j):
            fds.append([[(1+j,2+i+j),(2*f_tuple[1]-1-i-j,2*f_tuple[1]-j)], 0, 0])
            fds.append([[(rMod(f_tuple[0] + f_tuple[2] + f_tuple[3] + j,n),rMod(f_tuple[0] + f_tuple[2] + f_tuple[3] + j +i +1,n)),(rMod(f_tuple[0] + f_tuple[3] + f_tuple[2] + 2*f_tuple[1] - j -i - 2,n),rMod(f_tuple[0] + f_tuple[3] + f_tuple[2] + 2*f_tuple[1] - j - 1,n))], 0, 0])
    
    if debug[0]: print("fds final pass (cutout disks from disks): ")
    if debug[0]: print(fds)
    return fds


"""
generate_Disks

In: list of lists [[[[arcs] nz, nw], ... ] ]
Out: list of lists [[[p_1, q_1], nz, nw], ... ]

Eats a list of small regions and generates a list of disks. Should run
itself until no new disks are added. Add Multiplicities when stitching
regions together.
@author: zjermain15
"""
#[(8,11), (25, 15)] to (21, 24)
def diskmatch(R0,d0,j,k,n,fu): #determines if disks and fdn have matching gluing arcs
    p = fu
    if R0[j][0][k][0] > p and d0[n][0][0][0] <= p: #check disk and region are on opposite sides
        if R0[j][0][k][0] % p == d0[n][0][0][0] % p and R0[j][0][k][1] % p == d0[n][0][0][1] % p:
            return 1
    if R0[j][0][k][0] <= p and d0[n][0][0][0] > p : #checks disk and region are on opposite sides
        if R0[j][0][k][0] % p == d0[n][0][0][0] % p and R0[j][0][k][1] % p == d0[n][0][0][1] % p:
            return 1
    else:
        return 0
    #return (R0[j][0][k][0] + d0[n][0][0][0]) % p + (R0[j][0][k][1] + d0[n][0][0][1]) % p

def disklength(d,n,fu): #determines length of gluing arc for disk
    p = fu
    if d[n][0][0][0] > p: 
        if d[n][0][0][0] < d[n][0][0][1]: #determines lenght on right wihtout wrap around
            length = abs(d[n][0][0][0] - d[n][0][0][1])
        elif d[n][0][0][0] > d[n][0][0][1]: #determines length on right with wrap around
            length = abs(p - d[n][0][0][0] + d[n][0][0][1])
    if d[n][0][0][0] <= p:
        if d[n][0][0][0] < d[n][0][0][1]: #determines lenght on left wihtout wrap around
            length = abs(d[n][0][0][0] - d[n][0][0][1])
        elif d[n][0][0][0] > d[n][0][0][1]: #determines length on left without wrap around
            length = abs(p - d[n][0][0][0] + d[n][0][0][1])
    return length
   
def regionlength(R0,j,k,p): #determines length of gluing arcs for region
    if R0[j][0][k][0] > p:
        if R0[j][0][k][0] < R0[j][0][k][1]:
            length = abs(R0[j][0][k][0] - R0[j][0][k][1])
        if R0[j][0][k][0] > R0[j][0][k][1]:
            length = abs(2*p - R0[j][0][k][0] + R0[j][0][k][1] - p)
    if R0[j][0][k][0] <= p:
        if R0[j][0][k][0] < R0[j][0][k][1]:
            length = abs(R0[j][0][k][0] - R0[j][0][k][1])
        if R0[j][0][k][0] > R0[j][0][k][1]:
            length = abs(p - R0[j][0][k][0] + R0[j][0][k][1])
   
    return length
   
     
def diskfinder(regions,bar):
    p = bar[0]
    r = bar[3]
    d0 = []
    R0 = []
    Rcheck = []
    d1 = []
    attach = []
    for i in range(len(regions)): #cycles through list of fundamental domains, seperates out small disks
        if len(regions[i][0]) == 1:
            d0.append((regions[i][0],regions[i][1],regions[i][2]))
            
        elif len(regions[i][0]) != 1:
            R0.append((regions[i][0],regions[i][1],regions[i][2]))
            Rcheck.append((regions[i][0],regions[i][1],regions[i][2]))

    if debug[0] == True: print("d0: ", d0)
    attachcounter = 0 #counter for number of disks attatched to fundamental region
    zbase = 0
    wbase = 0
    for j in range(len(R0)): #cycles through and attatches small disks to fdn for first iteration
        attachcounter = 0
        zbase = R0[j][1]
        wbase = R0[j][2]
        for n in range(len(d0)):
            for k in range(len(R0[j][0])):
                if diskmatch(R0,d0,j,k,n,p) == 1 and disklength(d0,n,p) == regionlength(R0,j,k,p):
                    attach.append(R0[j][0][k])
                    zbase += (d0[n][1])
                    wbase += (d0[n][2])
                    attachcounter += 1

               
        if attachcounter == len(R0[j][0]) - 1:
            disc = [x for x in R0[j][0] if x not in attach] #finds the discs to attach to fundamental domain, and returns the remaining alpha arc that defines new disk
            d1.append((disc,zbase,wbase))
           
   
    loopcounter = 1
    newdisk = 0
    while loopcounter < p/2 + 1: #cyccles through remaining passes of finding disks
        attach = []
        d2 = []
        newdisk = 0
        disc = []
        for j in range(len(R0)):
            attachcounter = 0
            zbase = R0[j][1]
            wbase = R0[j][2]
            diskattach = 0 #counter for added disks from most recent iteration
            for n in range(len(d1)):
                for k in range(len(R0[j][0])):
                    if diskmatch(R0,d1,j,k,n,p) == 1 and disklength(d1,n,p) == regionlength(R0,j,k,p):
                        attach.append(R0[j][0][k])
                        zbase += (d1[n][1])
                        wbase += (d1[n][2])
                        attachcounter += 1
                        diskattach += 1

            if diskattach >= 1:
                for n in range(len(d0)):
                    for k in range(len(R0[j][0])):
                        if diskmatch(R0,d0,j,k,n,p) == 1 and disklength(d0,n,p) == regionlength(R0,j,k,p):
                            attach.append(R0[j][0][k])
                            zbase += (d0[n][1])
                            wbase += (d0[n][2])
                            attachcounter += 1
               
                if attachcounter == len(R0[j][0]) - 1:
                    disc = [x for x in R0[j][0] if x not in attach]
                    d2.append((disc,zbase,wbase))
                    newdisk += 1
                    
        if debug[0]: print("\n")
        if debug[0]: print("Lists of Disks")
        if debug[0]: print(d1)
        if debug[0]: print("\n")
        if debug[0]: print(d2)
        
        if newdisk == 0:
            break
        for n in range(len(d1)):
            d0.append(d1[n])
        d1 = []
        for n in range(len(d2)):
            d1.append(d2[n])

        loopcounter += 1
    for n in range(len(d1)):
        d0.append(d1[n])        
    if show_final_diskset: print("This is the set of final discs")
    if show_final_diskset: print(reduce_Generators(d0,bar))
    if show_final_diskset: print(len(d0))
    return d0

"""
generate_Complex

z - vertical shift
w - horizontal shift (pass over U get Ub (so b sits above a)) go over tiwce means
    arrow twice as long, and b sits two units above a
    
    Need to figure out how to sort info into a graph in the plane, using relative 
    positions of generators

Relative Alexander Gradings

Relative Maslov Grading

Absolute Maslov Grading

Tau -> Wil contract length 0 arrows, then length 1 arrows, etc.
--> Need to be able to stop at each stage (actually computing pages of spectral sequence)

Epsilon

Upsilon
"""

def reduce_Generators(unmodded_disk_set, four_tuple):
    disks = []
    
    #Mod the endpoints so generators match up i.e. for n=18, generator 28 = 10
    for disk in unmodded_disk_set:
        if disk[0][0][0] <= four_tuple[0]:
            disks.append(disk)
        else:#Recall, disks on RHS go from bottom to top
            disks.append(([(lMod(disk[0][0][1],four_tuple[0]), lMod(disk[0][0][0],four_tuple[0]))], disk[1], disk[2]))
    

    return disks

def find_Coords(disks, four_tuple): #Only works if there is a spanning tree
    n = four_tuple[0]
        
    #blank coordinate list
    coords = []
    
    #generate starting coords, let 'em all be a 0,0
    for i in range(1,n+1):
        coords.append([i, 0, 0])
    
    #find the spanning tree using the relations
    pos = [1]
    head = []
    tail = []
    used = []
    new = []
    placed = [1]
    
    while len(used) < n:
        
        for dot in pos:
            if dot not in used:
                #put it in the pile
                used.append(dot)
                
                #Get relaions it is the head of
                #Get relations it it the tail of
                for disk in disks:
                    if disk[0][0][1] == dot and disk[0][0][0] not in used: #at head
                        head.append(disk)
                    elif disk[0][0][0] == dot and disk[0][0][1] not in used: # at tail
                        tail.append(disk)
                        
                if debug[0]: print("/n")
                if debug[0]:print("dot: ",  dot)
                if debug[0]: print("head of:",  head)
                if debug[0]:print("tail of:",  tail)
                
                #apply relations from head, move down (z) and to the left (w)
                for rel in head:
                    if rel[0][0][0] not in placed: #if the geerator has not been placed yet
                        placed.append(rel[0][0][0])
                        coords[rel[0][0][0]-1] = [rel[0][0][0], coords[dot-1][1] + rel[2], coords[dot-1][2] + rel[1]]
                        if rel[0][0][0] not in new: new.append(rel[0][0][0]) #add to pile to  check
                    
    
                for rel in tail:
                    if rel[0][0][1] not in placed: #if the geerator has not been placed yet
                        placed.append(rel[0][0][1])
                        coords[rel[0][0][1]-1] = [rel[0][0][1], coords[dot-1][1] - rel[2], coords[dot-1][2] - rel[1]]
                        if rel[0][0][1] not in new: new.append(rel[0][0][1]) #add to pile to  check
                head = []
                tail = []    
        if debug[0]: print("Now Checking: ", new)
        pos = new
        new = []
    
    i = 0
    for coord in coords:
        #coord.append(basis[i])
        i +=1
    
    return adjust_Alexander(coords) #[gen, U-power, j, basis]

def adjust_Alexander(coordinates):
    x = 100000
    y = 100000
    for coord in coordinates:
        if coord[1] < x: x = coord[1] #farthest left
        if coord[2] < y: y = coord[2] #Farthest down
    for coord in coordinates:
        coord[1] = coord[1]-x
        coord[2] = coord[2]-y
    return coordinates

"""
Make Hat: throw out W arrows, everything lives on axis (v)
Could calculate Euler Char which would fix Alexander grading (because its symmetric)
Maslov: Make hat, calc homology (i.e. contract) surviving one is at Maslov = 0
Absolute Alexander (calc after Euler Characterist)
Order Mike would write functions: 
    -MakeHat
    -Euler Char
    -Calc Abs Alexander
"""
def make_Hat(a_complex, coords):
    hat_complex = copy.deepcopy(a_complex) #we want to preserve the OG thing
    hat_coords = copy.deepcopy(coords) #we want to preserve the OG thing
    temp = []
    for disk in a_complex:
        if disk[2] != 0:
            temp.append(disk)
    
    for bad_disk in temp:
        hat_complex.remove(bad_disk)
    
    for gen in hat_coords:
        grading_shift = gen[1]
        gen[1] = 0
        gen[2] = gen[2] - grading_shift
    
    return [hat_complex, hat_coords]


"""
connect sum

Two sets of data: [C1, Co1], [C2, Co2]
New set:
    (c1i, c2j) <tensor generators together>
    -New arrow whenever a set of coords the same (c1i, c2j) and (c1i, c2k)
    AND there already exists an arrow from c2j -> c2k.
    
    option to rename tensored gens from 1 to nm changing arrows accordingly.
    
    !!!WIP!!!

"""
def connect_Sum(C1, C2, G1, G2):
    comp1 = C1
    comp2 = C2
    tensored_gens = []
    i = 0
    for c1 in comp1:
        for c2 in comp2:
            tensored_gens.append(i, (c1, c2))
            i += 1
    
    tensored_coords = []
    for gen in tensored_gens:
        tensored_coords.append([gen, G1[gen[0]-1][1] + G2[gen[1]-1][1], G1[gen[0]-1][2] + G2[gen[1]-1][2]])
        
    tensor_complex = []
    for pair1 in tensored_gens:
        for pair2 in tensored_gens:
            if pair1[1][1] != pair2[1][1] and pair1[1][0] == pair2[1][0]:
                ind1 = pair1[0]
                ind2 = pair2[0]
                for arrow in C2:
                    if arrow[0] == [(pair1[1][1], pair2[1][1])]:
                        tensor_complex.append([(pair1[1][0], pair2[1][0]), (pair1[1][1], pair2[1][1])], abs(tensored_coords[ind1][2] - tensored_coords[ind2][2]), abs(tensored_coords[ind1][1] - tensored_coords[ind2][1]))    
            elif pair1[1][1] != pair2[1][1] and pair1[1][1] == pair2[1][1]:
                ind1 = pair1[0]
                ind2 = pair2[0]
                for arrow in C2:
                    if arrow[0] == [(pair1[1][0], pair2[1][0])]:
                        tensor_complex.append([(pair1[1][0], pair2[1][0]), (pair1[1][1], pair2[1][1])], abs(tensored_coords[ind1][2] - tensored_coords[ind2][2]), abs(tensored_coords[ind1][1] - tensored_coords[ind2][1]))
    
    return [tensor_complex, tensored_coords]

"""
Contraction Algorithm (Fast, for hat complex)
- addModTwo: should 'add' arrows mod 2
- eat arrow (identify head and tail)
-- Get Parents (of head)
-- Get Children (of tail)
---tie parents to children (mod 2)
"""
def contract(arrow, a_complex, coords): #a disk (arrow) to remove, the complex, and the coords
    new_complex = copy.deepcopy(a_complex) #We dont want to change the original thing
    new_basis = copy.deepcopy(coords) #We dont want to change the original thing
    
    #Identify Head and Tail
    head = arrow[0][0][1]
    tail = arrow[0][0][0]
    
   
    
    #Get Parents of head
    parents = []
    temp = []
    for disk in new_complex:
        if disk[0][0][1] == head and disk[0][0][0] != tail: #throw out arrows into head, collect parents
            parents.append(disk[0][0][0])
            temp.append(disk)
        if disk[0][0][0] == head: #throw out arrows leaving head
            temp.append(disk)
    
    #Get Children of tail
    children = []
    for disk in new_complex:
        if disk[0][0][0] == tail and disk[0][0][1] != head: #throw out arrows leaving tail, collect child
            children.append(disk[0][0][1])
            temp.append(disk)
        if disk[0][0][1] == tail: #throw out arrows into tail
            temp.append(disk)
    
    #cleanup by throwing out the arrows. But FIRST we should have calculated new disks.
    #Its should be: new arrow equals: (parent to head) + (tail to child) - (arrow)
    for parent in parents:
        for child in children:
            new_arrow = []
            length_1 = []
            length_2 = []

            for disk in a_complex:
                #print("checking: ", disk)
                if disk[0] == [(parent, head)]:
                    length_1 = [disk[1], disk[2]]
                elif disk[0] == [(tail, child)]:
                    length_2 = [disk[1], disk[2]]
            
            new_arrow.append(([(parent, child)], length_1[0] + length_2[0] - arrow[1], length_1[1] + length_2[1] - arrow[2]))
            if new_arrow[0] in new_complex: #add mod2
                new_complex.remove(new_arrow[0])
            else: new_complex.append(new_arrow[0])                
    
    #Actual cleanup
    for disk in temp: 
        new_complex.remove(disk)            
    
    
    return [new_complex, new_basis]

"""
calc S3 generator
1. Contract length 1 arrows in CFK^
2. Check if done (is there an isolated generator?) if not:
2+i. Contract length 1+i arrows and check if done.

The isolated generator is the S3 generator. 
tau = A(S3 generator)
"""
def calc_S3(hat_complex, hat_coords):
    contracted_complex = copy.deepcopy(hat_complex) #We want to preserve the original hat complex
    quiver = []
    length = 1
    S3_gen = 0
    while S3_gen == 0:
        arrow_was_contracted = False
            
        #grab a length i arrow
        for arrow in contracted_complex:
            if arrow[1] == length and arrow not in quiver: 
                quiver.append(arrow)
                contracted_complex = contract(arrow, contracted_complex, hat_coords)[0]
                arrow_was_contracted = True
                break
                
        if not arrow_was_contracted: 
            length += 1
            #check if done          
            for gen in range(1, len(hat_coords)+1):
                is_isolated = True
                for disk in contracted_complex: 
                    if disk[0][0][0] == gen or disk[0][0][1] == gen: is_isolated = False 
                if is_isolated: 
                    S3_gen = gen
                    break
        
        if length > 1000: sys.exit("I'ma keep on runnin' (arrow length exceeded 1000, if for some reason this is not unreasonable get rid of this sys.exit line)")
        
    return S3_gen

def spec_Sequence(hat_complex, hat_coords): 
    contracted_complex = copy.deepcopy(hat_complex) #We want to preserve the original hat complex
    quiver = []
    length = 1
    S3_gen = 0
    Ecounter = 0
    Esequence = []
    while S3_gen == 0:
        arrow_was_contracted = False
            
        #grab a length i arrow
        for arrow in contracted_complex:
            if arrow[1] == length and arrow not in quiver: 
                quiver.append(arrow)
                contracted_complex = contract(arrow, contracted_complex, hat_coords)[0]
                arrow_was_contracted = True
                break
        if not arrow_was_contracted:
            E = [i for i in hat_complex if i not in quiver]
            Esequence.append(E)
            print("E[",Ecounter,"] =", E,)
            print("\n")
            length += 1
            Ecounter += 1
            #check if done
            for gen in range(1, len(hat_coords)+1):
                is_isolated = True
                for disk in contracted_complex: 
                    if disk[0][0][0] == gen or disk[0][0][1] == gen: is_isolated = False 
                if is_isolated: 
                    S3_gen = gen
                    E = []
                    print("E[",Ecounter,"] =", E,)
                    Esequence.append(E)
                    break
            
        
        if length > 1000: sys.exit("I'ma keep on runnin' (arrow length exceeded 1000, if for some reason this is not unreasonable get rid of this sys.exit line)")
        
    return Esequence
        

"""
Add Generators
remember: Raise tails, lower heads (by difference of the addon's A gradings)
a-> c (-> c+b)
a-> b
arrows into c+b get copied to b
Arrows out of c+b get copied to children of b

"""
def add_Generators(addon, addto, C, G):
    new_complex = copy.deepcopy(C)
    adjust = abs(get_A_Grading(addto, G) - get_A_Grading(addon, G))
    
    arrows_out = []
    for arrow in new_complex: 
        #grab arrows out of addon
        if arrow[0][0][0] == addon: arrows_out.append(arrow)
    
    for arrow in arrows_out:
        new_arrow = ([(addto, arrow[0][0][1])]), arrow[1] + adjust , arrow[2]
        if new_arrow not in new_complex: 
            new_complex.append(new_arrow)
        else: new_complex.remove(new_arrow)
        
    arrows_in = []    
    for arrow in new_complex: 
        #grab arrows into of addto
        if arrow[0][0][1] == addto: arrows_in.append(arrow)

    for arrow in arrows_in: #just lower heads, they go to U^-i addon
        new_arrow = ([(arrow[0][0][0], addon)], arrow[1] + adjust, arrow[2])
        if new_arrow not in new_complex:
            new_complex.append(new_arrow)
        else: new_complex.remove(new_arrow)
        
    return new_complex

"""
Vertically Simplify
"""
def vert_Simplify(C, G):
    new_complex = copy.deepcopy(C)
    maxi = 0
    mini = 0
    
    for grads in G:
        if grads[2] > maxi: maxi = grads[2]
        if grads[2] < mini: mini = grads[2]
    
    max_length = maxi - mini
    
    #find length i vertical arrow, and add stuff until no length i vertical arrows
    length = 1
    quiver = []
    
    while length <= max_length:
        increase_length = True
        for arrow in new_complex:
            if arrow[2] == 0 and arrow[1] == length and arrow not in quiver: #only consider vertical arrows
                quiver.append(arrow)
                increase_length = False
                #get children of tail
                children = []
                for a in new_complex:
                    if a[0][0][0] == arrow[0][0][0] and a[0][0][1] != arrow[0][0][1] and a[2] == 0:
                        children.append(a[0][0][1])
                for child in children:
                    #print("adding ", child, " to ", arrow[0][0][1], " at length ", length)
                    new_complex = add_Generators(child, arrow[0][0][1], new_complex, G)
                
                #get parents of addto:
                parents = []
                for a in new_complex: 
                    if a[0][0][1] == arrow[0][0][1] and a[0][0][0] != arrow[0][0][0] and a[2] == 0:
                        parents.append(a[0][0][0])
                for parent in parents:
                    new_complex = add_Generators(arrow[0][0][0], parent, new_complex, G)
                
                break
            
        if increase_length: length += 1
    
    return new_complex

"""
Hor Simplify
!!!Untested!!!
"""
def hori_Simplify(C, G):
    new_complex = copy.deepcopy(C)
    maxi = 0
    mini = 0
    
    for grads in G:
        if grads[1] > maxi: maxi = grads[1]
        if grads[1] < mini: mini = grads[1]
    
    max_length = maxi - mini
    
    #find length i hori arrow, and add stuff until no length i hori arrows
    length = 1
    quiver = []
    
    while length <= max_length:
        increase_length = True
        for arrow in new_complex:
            if arrow[1] == 0 and arrow[2] == length and arrow not in quiver: #only consider hori arrows
                quiver.append(arrow)
                increase_length = False
                #get children of tail
                children = []
                for a in new_complex:
                    if a[0][0][0] == arrow[0][0][0] and a[0][0][1] != arrow[0][0][1] and a[1] == 0:
                        children.append(a[0][0][1])
                for child in children:
                    #print("adding ", child, " to ", arrow[0][0][1], " at length ", length)
                    new_complex = add_Generators(child, arrow[0][0][1], new_complex, G)
                
                #get parents of addto:
                parents = []
                for a in new_complex: 
                    if a[0][0][1] == arrow[0][0][1] and a[0][0][0] != arrow[0][0][0] and a[1] == 0:
                        parents.append(a[0][0][0])
                for parent in parents:
                    new_complex = add_Generators(arrow[0][0][0], parent, new_complex, G)
                
                break
            
        if increase_length: length += 1
    
    
    
    return new_complex

def rel_maslov(gradings, startpoint, endpoint): #takes in gradings of points and two points to find relative gradings
    x = startpoint
    y = endpoint
    #nz = gradings[x-1][2] - gradings[y-1][2] #calculates number of z basepoints
    nw = gradings[x-1][1] - gradings[y-1][1] #calculates number of w basebapoints
    phi = get_phi(calc_Complex(fourtuple),fourtuple,x,y) #finds total number of arrows between points for Maslov gradings      
    return phi -2*nw

def rel_alexander(gradings,startpoint,endpoint):
    x = startpoint
    y = endpoint
    nz = gradings[x-1][2] - gradings[y-1][2] #calculates number of z basepoints
    nw = gradings[x-1][1] - gradings[y-1][1] #calculates number of w basebapoints      
    return nz - nw
    

def find_path(graph, start, end, path=[]): #finds path between two generators (used to calculate phi)
        path = path + [start]
        if start == end:
            return path
        #if not graph.has_key(start):
        #    return None
        for node in graph[start]:
            if node not in path:
                newpath = find_path(graph, node, end, path)
                if newpath: return newpath
        return None
    
def get_phi(disks,fourtuple,startingpoint,endingpoint): #calculates phi to get Maslov gradings
    graph = {} 
    n = fourtuple[0]
    phi = 0
    x = startingpoint
    y = endingpoint
    
    for i in range(n): #writes disks into a dictionary 
        relations = []
        for j in range(len(disks)) :
            if disks[j][0][0][0] == i+1:
                relations.append(disks[j][0][0][1])
            elif disks[j][0][0][1] == i+1:
                relations.append(disks[j][0][0][0])
            graph[i+1] = relations

    path = (find_path(graph,x,y)) #gets path between two points 

    for i in range(len(path) -1): #calculates phi
        for j in range(len(disks)): 
            if path[i] == disks[j][0][0][0] and path[i+1] == disks[j][0][0][1] : #adds 1 for forward arrow
                phi += 1 
            elif path[i] == disks[j][0][0][1] and path[i+1] == disks[j][0][0][0]: #subtracts one for backward arrow
                phi -= 1
    return phi
"""
Epsilon
"""
def calc_Epsilon(C, G): #Feed a complex with gens on vertical axis
    new_complex = vert_Simplify(copy.deepcopy(C), G)
    
    #Identiify S3 Gen
    S3_gen = 0
    for gen in G:
        is_S3 = True
        for disk in new_complex:
            if (gen[0] == disk[0][0][0] or gen[0] == disk[0][0][1]) and disk[1] != 0 and disk[2] == 0: #if vertical arrow
                is_S3 = False
                break
        if is_S3:
            S3_gen = gen[0]
    
    #Need to examine maps C -> left arm complex / C -> right_arm complex
    #to see if they are trivial. Only one can be non-trivial.
    #To do this, we will simply calculate homology, jumping back and forth.
    
    #Left Arm
    #!!!Maybe add a check to first see if any arrows out.
    current_gens = [S3_gen]
    used_gens = [S3_gen]
    keep_going = True
    left_arm = []
    while keep_going:
        keep_going = False
        children = []
        for current_gen in current_gens: #find children of current, add disks to new complex
            for disk in new_complex:           
                if disk[0][0][0] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in left_arm: #tail of horiz arrow
                    left_arm.append(disk)
                    used_gens.append(disk[0][0][1])
                    children.append(disk[0][0][1])
                    
        current_gens = []
        for child in children: current_gens.append(child)
        
        parents = []
        for current_gen in current_gens: #find parents of current, add disks to new complex
            for disk in new_complex:           
                if disk[0][0][1] == current_gen and disk[1] == 0 and disk[2] != 0 and disk not in left_arm: #head of horiz arrow
                    keep_going = True #Were there parents? Cycle through again
                    left_arm.append(disk)
                    used_gens.append(disk[0][0][0])
                    parents.append(disk[0][0][0])
        
        current_gens = []
        for parent in parents: current_gens.append(parent)
        
        #We now have the complex starting at the S3 gen, and everything "connected to it"
        #Need to compute homology now. i.e. contract arrows to see if arrows out of S3 gen survive.
        
"""
def cps(complex):
    - Search for orphans
    - Search for single parent children
    -remove them from the complex
"""

"""
conjecture check:

"""
def check_Conjecture(s,m):
    to_check = []
    for p in range(s, m):
        for a in range(1, p):
            for b in range (1, p):
                for r in range(1, p):
                    T = [p, a, b, r]
                    
                    if fourtuple_Loop(p, a, b, r)[0] == False:
                        
                        print("Valid: ", T)
                        test_C = gen_Complex(T)
                        V = make_Vert(test_C[0], test_C[1])
                        #print(V)
                        maxi = -9999
                        for gen in range(len(V[1])):
                            if V[1][gen][2] > maxi: maxi = V[1][gen][2]
                        
                        #check second slot
                        check = maxi - 1
                        #print("Checking: ", check)
                        exists = False
                        for gen in range(len(V[1])):
                            if V[1][gen][2] == check: 
                                exists = True
                        
                        if exists == False: 
                            to_check.append(T)
    print("Check: ", to_check)                        
    print("Done")
    return 


"""
GUI
"""
def intro():
    print("Welcome! If you need help, type: _help('all')")

def _help(command):
    if command == 'all':    
        print("For example, you could calculate Tau:")
        print("Begin with a valid 4-tuple in a python 'list' (something like: 'T = [7,3,1,5]' )")
        print("We also assume that the z-basepoint is on the left hand side of the diagram.")
        print("\n")
        print("1. Generate the complex: 'C = gen_Complex(T)' ")
        print("1.a: This will return a List with two elements: [Disks, gradings] ")
        print("1.a.i: 'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
        print("1.a.ii: Each is a disk from gen_x to gen_y with w w-basepoints and z z-basepoints")
        print("1.b.i: 'gradings' are a List of: [gen, w, z] for each gen (note: it is really the U^w Translate of gen)")
        print("\n")
        print("2. Generate the hat complex: 'H = calc_Hat(C[0], C[1])' i.e. feed the complex and gradings ")
        print("2.a: This will return a List with two elements: [hat_disks, hat_gradings] ")
        print("2.a.i: 'Disks' are as above")
        print("2.b.i: 'gradings' are as above")
        print("\n")
        print("3. Calculate the S3 generator: 'S3 = calc_S3(H[0], H[1])' i.e. feed the hat complex and hat gradings ")
        print("4. Calculate Tau: 'get_Tau(S3, H[1])' i.e. requires S3 gen and generator gradings")
        print("\n")
        print("Full list of commands: gen_Complex(T), calc_Complex(T), calc_Hat(C, G), calc_Gradings(C, T), get_Tau(S3_gen, hat_gradings), vert_Simplify(C, G)")
        print("Type _help('function') for specific help.")
        print("Or ook at the code for more info.")
    elif command == 'gen_Complex':
        print("-This function eats a 4-Tuple, and returns a List with two elements [Disks, gradings] ")
        print("-'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
        print("-Each is a disk from gen_x to gen_y with w w-basepoints and z z-basepoints")
        print("1.b.i: 'gradings' are a List of: [gen, w, z] for each gen (note: it is really the U^w Translate of gen_)")
    elif command == 'calc_Complex':
        print("-This function eats a 4-Tuple, and returns List of 'Disks' ")
        print("-'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
    elif command == 'calc_Hat':
        print("-This function eats a complex and the associated gradings, and returns a List with two elements [Disks, gradings] ")
        print("-'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
        print("-Each is a disk from gen_x to gen_y with w w-basepoints and z z-basepoints")
        print("-Note: It should all be on the vertical axis")
    elif command == 'calc_Gradings':
        print("-This function eats a complex, and returns a List of i-gradings/j-gradings ")
        print("1.b.i: 'gradings' are a List of: [gen, w, z] for each gen (note: it is really the U^w Translate of gen_)")
    elif command == 'calc_S3':
        print("Feed it the hat complex followed by the grading set for the hat complex")
    elif command == 'get_Tau':
        print("Feed it the S3 gen, and the hat gradings")
    elif command == 'vert_Simplify':
        print("Feed it a complex <output of gen_Complex>, and the gradings for the complex")
    else: print("I can't help you, try again later. (and check your input)")
    
"""
Helper Functions
"""
    
def gen_Complex(T): #Requires a 4-Tuple
    C = calc_Complex(T)
    return [C, calc_Gradings(C, T)]

def calc_Complex(T): #Requires a 4-tuple
    
    return reduce_Generators(diskfinder(find_Fundamental_Domains(fourtuple(T[0], T[1], T[2], T[3]),T),T),T)

def calc_Hat(C, G): #requires a complex and its calculated gradings
    return make_Hat(C, G)

def calc_Gradings(C, T): #requires a complex and the 4-Tuple
    return find_Coords(C, T)

def get_A_Grading(gen, G):#requires a generator and a grading set
    return G[gen-1][2]

def get_Tau(S3_gen, hat_gradings): #Requires s3 generator and gradings of hat complex
    return hat_gradings[S3_gen - 1][2]

def make_Vert(C, G):
    temp = calc_Hat(C, G)
    return [C[0], temp[1]]


"""
MAIN
"""
intro()
debug = [False]
show_final_diskset = False
t = sym.Symbol('t')

#test = [[7,3,1,5]]
#test = [[13,3,4,3]]
#Some test code and cases
mike_test = [([(1, 2)], 2, 0), ([(1, 3)], 1, 0), ([(1, 4)], 0, 1), ([(2, 3)], 0, 1), ([(4, 3)], 2, 0)]
mike_grad = [[1, 0, 1],[2, 0, -1],[3, 0, 0],[4, 0, 2]]


"""
#debug = [fds cutout passes]
debug = [False]
t = sym.Symbol('t')
"""

test = []
#test.append([7,3,1,5])
#test.append([7,2,1,3])
test.append([9,2,3,2]) 
#test.append([3,1,1,1]) #3_1
#test.append([5,2,1,4] ) #4_1
#test.append([19,3,12,3])
#test.append([13,3,4,3]) #10_161
#test.append([13,5,3,1])
#test.append([9,4,1,1])
#test.append([13,4,1,6]) 

"""
test = [[7,2,1,3]]
"""

for test_4_tuple in test:
    basis = []
    
    for i in range(1,test_4_tuple[0]+1):
        basis.append(sym.Indexed('x',i))
    
    print("\n")
    print(test_4_tuple)
    fun_complex = gen_Complex(test_4_tuple)
    hat = calc_Hat(fun_complex[0], fun_complex[1])
    print("S3 gen: ", calc_S3(hat[0], hat[1]), ", Tau: ", get_Tau(calc_S3(hat[0], hat[1]), hat[1]))
    print("Spectral Sequence: ", spec_Sequence(hat[0], hat[1]))

#    #Make Hat:
##
#    print("\n")
#    print("Generator Gradings: (generator, i, j, basis)")
#    print(gradings)
#    hat_set = make_Hat(disk_set, gradings)
#    print("\n")
#    print("Hat Complex:")
#    print(hat_set[0])
#    print("\n")
#    print("Hat Coords:")
#    print(hat_set[1])

"""

"""

"""
=====================================================
=====================================================
=====================================================
PREVIOUS CODE I WANT TO KEEP
=====================================================
=====================================================
=====================================================

"""
