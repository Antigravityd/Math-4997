# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 14:15:41 2019

@author: Rob Quarles
@author: zjermain15
"""

#import numpy as np 
import sys

"""
Helper_Functions
"""
def lMod(number,n):
    if number == 0: number = n
    while number > n:
        number = number - n
    return number

#print(lMod(9,7)) = 2 as expected

def rMod(number, n):
    return lMod(number,n) + n
    
#print(rMod(15,7)) = 8 as expected

"""
input_Function
-> Should take input and call proper functions to calc invars

"""



"""
interpret_4tuple

In: 4-tuple (w,x,y,z)
Out: list of lists [[x_1, y_1],...,[x_n, y_n]]
 
Should interpret a given 4-tuple, determine if it is a (1,1)-knot, and return
a list of \beta arcs given as a Vector2 (start and end mark on diagram)
"""


def fourtuple(p,a,b,r):
    #check if four-tuple satifies algebraic restrictions
    if p%2 == 0:
        sys.exit("p is not odd. Invalid 4-tuple diagram")
       
    if a > p/2:
        sys.exit("a > p/2. Invalid 4-tuple diagram")
   
    if a < 1 or r < 1 or a > p or r > p:
        sys.exit("Invalid 4-tuple diagram")
       
    if b < 0 or b > (p-2*a):
        sys.exit("Invalid 4-tuple diagram")
    if 2*a + b + r < p:
        sys.exit("Invalid 4-tuple diagram")

    lines = []
    c = p -2*a - b
    #counts lines for small discs around w and z base points
    for i in range(a):
        lines.append((i+1,2*a-i)) #adds lines from left discs
        x = p + r + b + i#gives first intersection point for right discs
        if x > 2*p :        #checks if disc goes below one fundamental region
            x = x%(2*p) + p
        y = p + r + b + 2*a - i -1 #gives second interseciton point for right discs
        if y > 2*p:         #checks if disc goes below one fundamental region
            y = y %(2*p) + p
        lines.append((x,y))  #adds lines from right discs
    #adds b arcs
    for j in range(b):
        lines.append(((2*a+1+j),(p+r+j)))
   
   
    #adds arcs below base points
    for k in range(c):
        x = 2*p - c + r + k
        if x > 2*p:
            x = x%(2*p) + p
       
        lines.append((p-c+1+k,x))
       
    beta = [] #new list to check for a closed beta arc
    beta.append(lines[0]) #adds first arc to beta
    permutation = [] #list to check for permutation of all intersection points and crossing number
    permutation.append((lines[0][0],1)) #adds first point and appropriate crossing number
    permutation.append((lines[0][1],-1))
    n = 0 # counter for beta index
    l = 0 #counter for beta loop check
    print(lines)
    print(len(lines))
    while l < len(lines) -1: # runs for all curves in 4 tuple to check one closed beta curve
        while n == 0: #connects the first arc to the starting arc (makes sure starting arc is not repeated)
            for m in range(1,len(lines)):
                if beta[n][1] % p == lines[m][0] % p: #finds the arc which starts at the endpoint of the first arc
                    beta.append((lines[m])) #adds arc to beta list
                    permutation.append((lines[m][0],1)) #adds first point, with crossing number
                    permutation.append((lines[m][1],-1)) #adds second point, with crossing number
                    n+=1 #proceeds to next beta index
                    l+=1 #procees in loop
                elif (beta[n][1] % p == lines [m][1] % p):
                   beta.append((lines[m][1],lines[m][0])) #adds arc, and switches order of points to corrctly define curve
                   permutation.append((lines[m][1],1)) #adds point with crossing number
                   permutation.append((lines[m][0],-1)) #adds point with crossing number
                   n+= 1
                   l+= 1  
        for m in range(len(lines)): #attempts to connect all remaining arcs to find one closed beta curve
            #while l < len(lines) -1:
                if beta[n][1] % p == lines[m][0] % p: #finds arc which starts at the endpoint of current arc
                    if len(beta) > len(lines) -1 :
                        break
                    beta.append((lines[m]))
                    permutation.append((lines[m][0],1))
                    permutation.append((lines[m][1],-1))
                    n += 1
                    l += 1
                elif beta[n][1] % p == lines[m][1] % p:
                    if len(beta) > len(lines) -1:
                        break
                    beta.append((lines[m][1],lines[m][0]))
                    permutation.append((lines[m][1],1))
                    permutation.append((lines[m][0],-1))
                    n += 1
                    l += 1
                if beta[n] == beta[0]: #checks that beta defines one closed curve, no repeats
                    sys.exit("Beta does not define one closed curve. You have reached the starting point before hitting all generators")
   
    print(beta)
    print(len(beta))
    for q in range(1,len(lines)):#checks if beta defines one closed curve
        if beta[q] == beta[0] or (beta[q][1],beta[q][0]) == beta[0]:
            sys.exit("Beta does not define one closed curve")
    if (beta[p-1][1]) % p  != beta[0][0] % p:
        sys.exit("Beta does not define one closed curve. Curve doesn't end at starting point")
   
    i = 0
    leftcross = 0
    rightcross = 0
    for i in range(2*len(lines)): #calculates crossing number for each side
        if permutation[i][0] <= p:
            leftcross += permutation[i][1]
        if permutation[i][0] > p:
            rightcross += permutation[i][1]
    if debug[0]: print(leftcross)
    if debug[0]: print(rightcross)
    if leftcross == 1 or leftcross == -1: #checks if crossing number for left side is +-1
        if debug[0]: print("Crossing number for left side is correct")
    elif leftcross != 1 or leftcross != -1:
        sys.exit("Crossing number for left side is not 1 or -1")
    if rightcross == 1 or rightcross == -1: #checks if crossing number for right side is +-1
        if debug[0]: print("Crossing number for right side is correct")
    elif rightcross != 1 or rightcross != -1:
        sys.exit("Crossing number for right side is not 1 or -1")
           
       
           
     
   
    #print(beta)
    #print(len(permutation))
    #print(permutation[0])
    #print(permutation[1])
    return beta

#test_arcs = [(1,4),(11,14),(7,9),(2,3),(10,5),(12,13),(6,8)]


"""
find_Regions

In: list of lists [[x_1, y_1],...,[x_n, y_n]]
Out: list of lists [[[boundary arcs] nz, nw], ... ]

Eats a list of lines defining the \beta arcs and return a lsit of small
regions [gen 1, gen 2, z multiplicity, w multiplicity]
"""

def find_Regions(arcs, f_tuple): 
    #Get length of list:
    n = f_tuple[0]
    
    #create master list of gluing arcs
    g_arcs = []
    small_regions = []
    
    #generate master list of gluing arcs (left side)
    for zero_index in range(0,n):
        
        #fix indexing issues
        i = zero_index + 1
        
        #populuate the master list of gluing arcs
        g_arcs.append((i,lMod(i+1,n)))
        #g_arcs.append((i,lMod(i-1,n)))

    #generate master list of gluing arcs (right side)
    for zero_index in range(0,n):
        
        #fix indexing issues
        i = zero_index + 1 + n
        
        #populuate the master list of gluing arcs
        g_arcs.append((i,rMod(i+1,n)))
        #g_arcs.append((i,rMod(i-1,n)))
    
    #print (g_arcs)
    #generate small regions by picking directed paths out of the master list
    #and using the guide of the arcs
    for zero_index in range(0,2*n):
        #fix indexing issues
        i = zero_index + 1
        pos = i
        start_pos = i
        
        #keeps track of if we are on the RHS after starting on the LHS
        changed_sides = False #our first check will not change sides by construction

        temp_region = []
        unfinished_region = True
        
        while unfinished_region:
            
            if changed_sides == False: #we havent switched sides yet
                for arc in g_arcs:
                    
                    #if your position matches that of a gluing arc
                    if arc[0] == pos:
                        
   
                        pos = arc[1] #move to other endpoint (DOWN)
                        
                        #add the gluing arc to your small region
                        temp_region.append(arc)
                        
                        #change position based on the paths in the diagram
                        for path in arcs:
                            
                            if path[0] == pos:
                                pos = path[1]
                                #Did we switch to the RHS?
                                if path[0] <= n and path[1] > n: changed_sides = True
                                break
                            elif path[1] == pos:
                                pos = path[0]
                                #Did we switch to the RHS?
                                if path[1] <= n and path[0] > n: changed_sides = True
                                break
                        #Remove the gluing arc from our master list; we dont want duplicates
                        g_arcs.remove((arc[0],arc[1]))
                        #g_arcs.remove((arc[1],arc[0]))
                            
                        break
                if pos == start_pos: unfinished_region = False
                
            else: #We have switched to the RHS
                for arc in g_arcs:
                    
                    #if your position matches that of a gluing arc
                    if arc[1] == pos:
                           
                        pos = arc[0] #move UP
                        
                        #add the gluing arc to your small region
                        temp_region.append(arc)
                        
                        #change position based on the paths in the diagram
                        for path in arcs:
                            
                            if path[0] == pos:
                                pos = path[1]
                                #Did we switch back to LHS?
                                if path[0] > n and path[1] <= n: changed_sides = False
                                break
                            elif path[1] == pos:
                                pos = path[0]
                                #Did we switch back to LHS?
                                if path[1] > n and path[0] <= n: changed_sides = False
                                break
                            
                        g_arcs.remove((arc[0],arc[1]))
                        #g_arcs.remove((arc[1],arc[0]))
                            
                        break
                if pos == start_pos: unfinished_region = False
            
        #Once the loop is done, add your small region    
        if temp_region != []: small_regions.append(temp_region)
        
        #Notes: By the time we finish cycling through the LHS, we have gotten
        #every small regions besides the "Small disks" on the RHS which will
        #be counted by the first part of the algorithm normally.
        
        #Now we just need to calculate basepoints, but there should only be
        #two! The size one small regions.
        regions_with_basepoints = []

        for region in small_regions:
            if len(region) == 1:
                if region[0][0] > n: #Add W basepoint
                   regions_with_basepoints.append([region, 0, 1])
                if region[0][0] < n: #Add Z basepoint
                   regions_with_basepoints.append([region, 1, 0]) 
            else: regions_with_basepoints.append([region, 0, 0]) 
    
    return regions_with_basepoints

"""
find_Fundamental_Domains

In: list of lists [[x_1, y_1],...,[x_n, y_n]]
Out: list of lists [[[boundary arcs on sides] nz, nw], ... ]

We want to calculate fundamentl regions in the 3 ways presented in the paper.
1. arcs above other arcs
2. disks cut out of disks
3. disks cut out of regions
"""

def find_Fundamental_Domains(arcs, f_tuple):
    #Get length of list:
    n = f_tuple[0]
    
    #create master list of fundamental domains defined by gluing arcs
    fds = []
    
    #sort arcs to start on LHS (keep disks same)
    sorted_arcs= []
    for arc in arcs:
        #If Cross diagram
        if (arc[0] <= n and arc[1] > n) or (arc[0] > n and arc[1] <= n):
            if arc[0] < arc[1] : sorted_arcs.append(arc) #Sorts arcs
            else: sorted_arcs.append((arc[1],arc[0]))
        
    #generate sorted disks.
    n_disks_on_side = f_tuple[1]
    for i in range(n_disks_on_side):
        sorted_arcs.append((1+i,2*n_disks_on_side - i)) #LHS
        sorted_arcs.append((rMod(f_tuple[0] + f_tuple[2] + f_tuple[3] + i,n) ,rMod(f_tuple[0] + f_tuple[3] + f_tuple[2] + 2*f_tuple[1] - i - 1,n)))
    
    #print(sorted_arcs)
    #index for arcs matches sorted_arcs
    
    #split sorted arcs into two groups: disks and not disks
    sorted_arcs_no_disks = []
    fundamental_disks = []
    #take out disks
    for arc in sorted_arcs:
        #This does indeed grab disks on RHS that wrap around.
        if (arc[0] <= n and arc[1] <= n) or (arc[0] > n and arc[1] > n):
            fundamental_disks.append(arc)
            if arc[0] <= n: #add disk with multiplicity to fds
                fds.append([[arc], 1, 0])
            else: fds.append([[arc], 0, 1])
        else: sorted_arcs_no_disks.append(arc)

    #Method one: Compare endpoints of arcs from one side of the diagram to the 
    #other
    
    used_arcs = []
    #Cycle through arcs
    for top_arc in sorted_arcs_no_disks: 
        
        #Make sure the arc starts on one side and ends on the other
        if (top_arc[0] <= n and top_arc[1] > n): #left to right
            
            for bot_arc in sorted_arcs_no_disks:
               
                if (top_arc != bot_arc) and (bot_arc not in used_arcs):                        
                    fds.append([[(top_arc[0], bot_arc[0]),(top_arc[1], bot_arc[1])], 0, 0])
                    fds.append([[(bot_arc[0], top_arc[0]),(bot_arc[1], top_arc[1])], 0, 0])
                    
        used_arcs.append(top_arc)
    if debug[0]: print("Small Disks: ")
    if debug[0]: print(fundamental_disks)
    if debug[0]: print("fds after first pass (above below): ")
    if debug[0]: print(fds)
    if debug[0]: print(len(fds))
    flag = False
    # ARC wrap around multiplicities:
    for i in range(len(fds)):
        if len(fds[i][0])> 1:
            if fds[i][0][0][0] > fds[i][0][0][1]: #wrap around LHS, add multiplicity
                fds[i][1] = 1
                
            #if fds[i][0][0][0] == 19 and fds[i][0][0][1] == 9 and fds[i][0][1][0] == 21 and fds[i][0][1][1] == 24: flag = True
            for disk in fundamental_disks: #compare to fund disks on RHS, add multiplicity
                if disk[0] > n: #disk on RHS
                    if (fds[i][0][1][0] < disk[0] and fds[i][0][1][1] > disk[1]) and fds[i][0][1][1] > fds[i][0][1][0] and disk[0] < disk[1]: #disk inside gluing region
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 1st if statement in ARC WRAP")
                            print("Disk is: " , disk)
                            flag = False
                        break
                    elif fds[i][0][1][0] > fds[i][0][1][1] and fds[i][0][1][0] < disk[0]:# Wrap/anchors above
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 2nd if statement in ARC WRAP")
                            flag = False
                        break
                    elif fds[i][0][1][0] > fds[i][0][1][1] and fds[i][0][1][0] > disk[1]:# Wrap/anchors below
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 3rd if statement in ARC WRAP")
                            flag = False
                        break
                    elif fds[i][0][1][0] > fds[i][0][1][1] and (fds[i][0][1][0] > disk[1] and fds[i][0][1][1] < disk[0]) and disk[0] > disk[1]:# anchors between/ disk wrap
                        fds[i][2] = 1
                        if flag: 
                            print("Flag on 4th if statement in ARC WRAP")
                            flag = False
                        break
            

    if debug[0]: print("fds after 2nd pass (wrap around multiplicities added): ")
    if debug[0]: print(fds)
    
    #Method 2: Take disks out of fds
    temp = []
 
    for fd in fds:
        if len(fd[0]) >1 : #its not a disk so continue
            lwrap = False
            flag = False
            g_arcs = fd[0]
            if g_arcs[0] == (9,10): flag = True #Checking (9,10),(25,34),(20,25)
            
            #LHS need g_arc[0][0] > g_arc[0][1] i.e. wrap around
            if g_arcs[0][0] > g_arcs[0][1]: 
                lwrap = True
                for disk in fundamental_disks: #On LHS take out all the disks on LHS
                    if disk[0] <= n: #disks on LHS
                        temp.append([[(g_arcs[0][0],disk[0]),(disk[1],g_arcs[0][1]),g_arcs[1]], 0 , fd[2]])
           
            #We will cycle through disks to see if any can be taken out of the right.
            for disk in fundamental_disks: #compare to fund disks on RHS
                if disk[0] > n: #disk on RHS
                    if g_arcs[1][0] < disk[0] < disk[1] < g_arcs[1][1]:
                    #if (g_arcs[1][0] < disk[0] and g_arcs[1][1] > disk[1]) and g_arcs[1][1] > g_arcs[1][0] and disk[0] < disk[1]: #disk inside gluing region
                        temp.append([[g_arcs[0],(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], fd[1] , 0])
                        if flag: print("Case 1 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], 0 , 0])
                    
                    elif g_arcs[1][1] < g_arcs[1][0] < disk[0] < disk[1]:   
                    #elif g_arcs[1][0] > g_arcs[1][1] and g_arcs[1][0] < disk[0]:# Wrap/anchors above
                        temp.append([[g_arcs[0],(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], fd[1] , 0])
                        if flag: print("Case 2 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], 0 , 0])
                   
                    elif disk[0] < disk[1] < g_arcs[1][1] < g_arcs[1][0]:
                    #elif g_arcs[1][0] > g_arcs[1][1] and g_arcs[1][0] > disk[1]:# Wrap/anchors below
                        temp.append([[g_arcs[0],(g_arcs[1][1],disk[0]),(disk[1],g_arcs[1][0])], fd[1] , 0])
                        if flag: print("Case 3 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][1],disk[0]),(disk[1],g_arcs[1][0])], 0 , 0])
                   
                    elif disk[1] < g_arcs[1][1] < g_arcs[1][0] < disk[0]:
                    #elif g_arcs[1][0] > g_arcs[1][1] and (g_arcs[1][0] > disk[1] and g_arcs[1][1] < disk[0] and disk[0] > disk[1]):# anchors between/ disk wrap
                        temp.append([[g_arcs[0],(disk[0],g_arcs[1][0]),(g_arcs[1][1],disk[1])], fd[1] , 0])
                        if flag: print("Case 4 error")
                        if lwrap: #Need to cut out some combinations of disks
                            for ldisk in fundamental_disks: #On LHS take out all the disks on LHS
                                if ldisk[0] <= n: #disks on LHS
                                    temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(disk[0],g_arcs[1][0]),(g_arcs[1][1],disk[1])], 0 , 0])
                
       
    for t in temp:
        fds.append(t)
    
    if debug[0]: print("fds after third pass (cut out disks from regions): ")
    if debug[0]: print(fds)
    
    #Method 3: Disks from disks, (run last) (n,d,a,r)
    for j in range(f_tuple[1] - 1):
        for i in range(f_tuple[1]-1-j):
            fds.append([[(1+j,2+i+j),(2*f_tuple[1]-1-i-j,2*f_tuple[1]-j)], 0, 0])
            fds.append([[(rMod(f_tuple[0] + f_tuple[2] + f_tuple[3] + j,n),rMod(f_tuple[0] + f_tuple[2] + f_tuple[3] + j +i +1,n)),(rMod(f_tuple[0] + f_tuple[3] + f_tuple[2] + 2*f_tuple[1] - j -i - 2,n),rMod(f_tuple[0] + f_tuple[3] + f_tuple[2] + 2*f_tuple[1] - j - 1,n))], 0, 0])
    
    if debug[0]: print("fds final pass (cutout disks from disks): ")
    if debug[0]: print(fds)
    return fds


"""
generate_Disks

In: list of lists [[[[arcs] nz, nw], ... ] ]
Out: list of lists [[[p_1, q_1], nz, nw], ... ]

Eats a list of small regions and generates a list of disks. Should run
itself until no new disks are added. Add Multiplicities when stitching
regions together.
@author: zjermain15
"""
def diskmatch(R0,d0,j,k,n,fu):
    p = fu
    if R0[j][0][k][0] % p == d0[n][0][0][0] % p and R0[j][0][k][1] % p == d0[n][0][0][1] % p:
        return 1
    else:
        return 0
    #return (R0[j][0][k][0] + d0[n][0][0][0]) % p + (R0[j][0][k][1] + d0[n][0][0][1]) % p

def disklength(d0,n,p,rpoint):
    if d0[n][0][0][0] > rpoint and d0[n][0][0][1] < rpoint:
        length = (2*p - d0[n][0][0][0]) + (d0[n][0][0][1] - p)
    elif d0[n][0][0][0] < rpoint and d0[n][0][0][1] > rpoint:
        length = (2*p - d0[n][0][0][1]) + (d0[n][0][0][0] - p)
    else:
        length = abs(d0[n][0][0][0] - d0[n][0][0][1])
    return length
   
def regionlength(R0,j,k,p):
    if R0[j][0][k][0] > p:
        if R0[j][0][k][0] < R0[j][0][k][1]:
            length = abs(R0[j][0][k][0] - R0[j][0][k][1])
        if R0[j][0][k][0] > R0[j][0][k][1]:
            length = abs(2*p - R0[j][0][k][0] + R0[j][0][k][1] - p)
        #if R0[j][0][k][0] >= rpoint and R0[j][0][k][1] <= rpoint:
         #   length = (2*p - R0[k][0][k][0]) + (R0[j][0][k][1] - p)
        #elif R0[j][0][k][0] <= rpoint and R0[j][0][k][1] >= rpoint:
        #    length = (2*p - R0[k][0][k][1]) + (R0[j][0][k][0] - p)
        #else:
        #    length = abs(R0[j][0][k][0] - R0[j][0][k][1])
    if R0[j][0][k][0] <= p:
        if R0[j][0][k][0] < R0[j][0][k][1]:
            length = abs(R0[j][0][k][0] - R0[j][0][k][1])
        if R0[j][0][k][0] > R0[j][0][k][1]:
            length = abs(p - R0[j][0][k][0] + R0[j][0][k][1])
   
    return length
   
     
def diskfinder(regions,bar):
    p = bar[0]
    r = bar[3]
    d0 = []
    R0 = []
    Rcheck = []
    d1 = []
    attach = []
    for i in range(len(regions)): #cycles through list of fundamental domains, seperates out small disks
        if len(regions[i][0]) == 1:
            d0.append((regions[i][0],regions[i][1],regions[i][2]))
        elif len(regions[i][0]) != 1:
            R0.append((regions[i][0],regions[i][1],regions[i][2]))
            Rcheck.append((regions[i][0],regions[i][1],regions[i][2]))
    #print(d0)
    #print(R0)
   
    attachcounter = 0 #counter for number of disks attatched to fundamental region
    zbase = 0
    wbase = 0
    rpoint = p + r
    for j in range(len(R0)):
        attachcounter = 0
        zbase = 0
        wbase = 0
        for n in range(len(d0)):
            for k in range(len(R0[j][0])):
                if diskmatch(R0,d0,j,k,n,p) == 1 and disklength(d0,n,p,rpoint) == regionlength(R0,j,k,p):
                    attach.append(R0[j][0][k])
                    zbase += (R0[j][1] + d0[n][1])
                    wbase += (R0[j][2] + d0[n][2])
                    attachcounter += 1
                    #print(attachcounter)
               
        if attachcounter == len(R0[j][0]) - 1:
            #print(n)
            #print(j)
            #print(R0[j][0])
            disc = [x for x in R0[j][0] if x not in attach] #finds the discs to attach to fundamental domain, and returns the remaining alpha arc that defines new disk
            #print(disc)
            d1.append((disc,zbase,wbase))
           
   
    loopcounter = 1
    newdisk = 0
    while loopcounter < p/2 + 1:
        attach = []
        d2 = []
        newdisk = 0
        disc = []
        for j in range(len(R0)):
            attachcounter = 0
            zbase = 0
            wbase = 0
            diskattach = 0 #counter for added disks from most recent iteration
            for n in range(len(d1)):
                for k in range(len(R0[j][0])):
                    if diskmatch(R0,d1,j,k,n,p) == 1 and disklength(d1,n,p,rpoint) == regionlength(R0,j,k,p):
                        attach.append(R0[j][0][k])
                        zbase += (R0[j][1] + d1[n][1])
                        wbase += (R0[j][2] + d1[n][2])
                        attachcounter += 1
                        diskattach += 1
                        #print(R0[j])
                        #print(newdisk)
            if diskattach >= 1:
                for n in range(len(d0)):
                    for k in range(len(R0[j][0])):
                        if diskmatch(R0,d0,j,k,n,p) == 1 and disklength(d0,n,p,rpoint) == regionlength(R0,j,k,p):
                            #attach = check[j][0][k]
                            #check[j][0].remove(attach)
                            attach.append(R0[j][0][k])
                            zbase += (R0[j][1] + d0[n][1])
                            wbase += (R0[j][2] + d0[n][2])
                            attachcounter += 1
                            #print(R0[j])
                            #print(attachcounter)
                            #print(loopcounter)
               
                if attachcounter == len(R0[j][0]) - 1:
                    disc = [x for x in R0[j][0] if x not in attach]
                    d2.append((disc,zbase,wbase))
                    newdisk += 1
        if debug[0]: print("\n")
        if debug[0]: print("Lists of Disks")
        if debug[0]: print(d1)
        if debug[0]: print("\n")
        if debug[0]: print(d2)
        #print("\n")
        #print(d0)
        #print(loopcounter)
        if newdisk == 0:
            break
        for n in range(len(d1)):
            d0.append(d1[n])
        d1 = []
        for n in range(len(d2)):
            d1.append(d2[n])
           
        #for n in range(len(d1)):
        #    d0.append(d1[n])
        loopcounter += 1
        #print(d1)
        #print("\n")
        #print(d2)
        #print("\n")
        #print(d0)
        #print(loopcounter)
    for n in range(len(d1)):
        d0.append(d1[n])        
    print("This is the set of final discs")
    print(d0)
    #print(d1)
    print(d2)
    print(len(d0))


"""
toss_Duplicates

In: list of lists [[[p_1, q_1], nz, nw], ... ]
Out: list of lists [[[p_1, q_1], nz, nw], ... ]

Eats a list of disks, identifies and tosses duplicates, returning whats left.
"""




"""
generate_Complex

Store as adjacency matrix? ((0,0,0),(1,0,0),(1,0,0))
Or two? Even to Odd, Odd to Even
20x20 = 400 vs 12x8 + 8x12 = 192

Computing homology -> Some linear algebra problem concerning adjacency

~ Calc Invars, compute differentials, whatever.

Perhaps we should represent the graphical info as the following:
[(i1,j1),(i2,j2)] for directed arrows
[(i,j)] for isolated points

z - vertical shift
w - horizontal shift (pass over U get Ub (so b sits above a)) go over tiwce means
    arrow twice as long, and b sits two units above a
    
    Need to figure out how to sort info into a graph in the plane, using relative 
    positions of generators

Relative Alexander Gradings

Relative Maslov Grading

Absolute Maslov Grading

Tau -> Wil contract length 0 arrows, then length 1 arrows, etc.
--> Need to be able to stop at each stage (actually computing pages of spectral sequence)

Epsilon

Upsilon
"""


"""
MAIN
"""
#debug = [fds cutout passes]
debug = [True]
#
#test_4_tuple = [7,3,1,5]
#test_4_tuple = [7,2,1,3]
#arcs = [(1,4),(11,14),(7,9),(2,3),(10,5),(12,13),(6,8)]
#test_4_tuple = [3,1,1,1] 
#arcs = [(1,2),(5,6),(3,4)]
#test_4_tuple = [5,2,1,4] 
#arcs = [(1,4),(9,5),(10,8),(3,2),(7,6)]

test_4_tuple = [19,3,12,3]
#test_4_tuple = [9,4,1,1]
arcs = fourtuple(test_4_tuple[0], test_4_tuple[1], test_4_tuple[2], test_4_tuple[3])

small = find_Fundamental_Domains(arcs,test_4_tuple)
diskfinder(small,test_4_tuple)
#print(small)








"""
=====================================================
=====================================================
=====================================================
PREVIOUS CODE
=====================================================
=====================================================
=====================================================

-> This was too restrictive. Its even easier; just check they are on the same sides

def find_Fundamental_Domains(arcs, f_tuple):
    #Get length of list:
    n = f_tuple[0]
    
    #create master list of fundamental domains defined by gluing arcs
    fds = []
    
    #Method one: Compare endpoints of arcs from one side of the diagram to the 
    #other

    #Cycle through arcs
    for top_arc in arcs:
        
        #Make sure the arc starts on one side and ends on the other
        if (top_arc[0] <= n and top_arc[1] > n): #left to right
            
            for bot_arc in arcs:
                
                if (bot_arc[0] <= n and bot_arc[1] > n): #left to right
                    
                    if (top_arc[0] < bot_arc[0]) and (top_arc[1] < bot_arc[1]): #above below true
                        
                        fds.append([[(top_arc[0], bot_arc[0]),(top_arc[1], bot_arc[1])], 0, 0])
                
                elif (bot_arc[1] <= n and bot_arc[0] > n): #right to left
                    if (top_arc[0] < bot_arc[1]) and (top_arc[1] < bot_arc[0]): #above below true
                        
                        fds.append([[(top_arc[0], bot_arc[1]),(top_arc[1], bot_arc[0])], 0, 0])
                        
        elif (top_arc[1] <= n and top_arc[0] > n): #right to left
            for bot_arc in arcs:
                
                if (bot_arc[0] <= n and bot_arc[1] > n): #left to right
                    
                    if (top_arc[1] < bot_arc[0]) and (top_arc[0] < bot_arc[1]): #above below true
                        
                        fds.append([[(top_arc[1], bot_arc[0]),(top_arc[0], bot_arc[1])], 0, 0])
                
                elif (bot_arc[1] <= n and bot_arc[0] > n): #right to left
                    if (top_arc[1] < bot_arc[1]) and (top_arc[0] < bot_arc[0]): #above below true
                        
                        fds.append([[(top_arc[1], bot_arc[1]),(top_arc[0], bot_arc[0])], 0, 0])
                        
            
    #Method 2
    
    #Method 3
    
    
    return fds
    
    --------- cutout stuff
     #Need to reevaluate for (7,3,1,5)!!! (See above comparison)
            #RHS need g_arc[1][0] > g_arc[1][1] i.e. wrap around?? !!!!
            if g_arcs[1][0] > g_arcs[1][1]:
                for disk in fundamental_disks:
                    if disk[0] > n: #disks on RHS
                        temp.append([[g_arcs[0],(g_arcs[1][0],disk[0]),(disk[1],g_arcs[1][1])], fd[1] , 0])
            
            #wrap around twice! take out each side, cut out a bunch of disks
            if (g_arcs[0][0] > g_arcs[0][1]) and (g_arcs[1][0] > g_arcs[1][1]): 
                for ldisk in fundamental_disks:
                    if ldisk[0] <= n: #disks on LHS
                        for rdisk in fundamental_disks:
                            if rdisk[0] > n: #disks on RHS
                                
                                #Cut out both ldisk and rdisk
                                temp.append([[(g_arcs[0][0],ldisk[0]),(ldisk[1],g_arcs[0][1]),(g_arcs[1][0],rdisk[0]),(rdisk[1],g_arcs[1][1])], 0 , 0])

"""
