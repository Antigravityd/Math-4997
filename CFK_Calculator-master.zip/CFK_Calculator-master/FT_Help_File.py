# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 12:11:52 2020

@author: Rob Quarles
"""

"""
GUI
"""
def intro():
    print("Welcome! If you need help, type: h._help('all')")

def _help(command):
    if command == 'all':    
        print("For example, you could calculate Tau:")
        print("Begin with a valid 4-tuple in a python 'list' (something like: 'T = [7,3,1,5]' )")
        print("We also assume that the z-basepoint is on the left hand side of the diagram.")
        print("\n")
        print("1. Generate the complex: 'C = gen_Complex(T)' ")
        print("1.a: This will return a List with two elements: [Disks, gradings] ")
        print("1.a.i: 'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
        print("1.a.ii: Each is a disk from gen_x to gen_y with w w-basepoints and z z-basepoints")
        print("1.b.i: 'gradings' are a List of: [gen, w, z] for each gen (note: it is really the U^w Translate of gen)")
        print("\n")
        print("2. Generate the hat complex: 'H = calc_Hat(C[0], C[1])' i.e. feed the complex and gradings ")
        print("2.a: This will return a List with two elements: [hat_disks, hat_gradings] ")
        print("2.a.i: 'Disks' are as above")
        print("2.b.i: 'gradings' are as above")
        print("\n")
        print("3. Calculate the S3 generator: 'S3 = calc_S3(H[0], H[1])' i.e. feed the hat complex and hat gradings ")
        print("4. Calculate Tau: 'get_Tau(S3, H[1])' i.e. requires S3 gen and generator gradings")
        print("\n")
        print("Full list of commands: gen_Complex(T), calc_Complex(T), calc_Hat(C, G), calc_Gradings(C, T), get_Tau(S3_gen, hat_gradings), vert_Simplify(C, G)")
        print("Type _help('function') for specific help.")
        print("Or ook at the code for more info.")
    elif command == 'gen_Complex':
        print("-This function eats a 4-Tuple, and returns a List with two elements [Disks, gradings] ")
        print("-'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
        print("-Each is a disk from gen_x to gen_y with w w-basepoints and z z-basepoints")
        print("1.b.i: 'gradings' are a List of: [gen, w, z] for each gen (note: it is really the U^w Translate of gen_)")
    elif command == 'calc_Complex':
        print("-This function eats a 4-Tuple, and returns List of 'Disks' ")
        print("-'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
    elif command == 'calc_Hat':
        print("-This function eats a complex and the associated gradings, and returns a List with two elements [Disks, gradings] ")
        print("-'Disks' are a List of things in the form: ([(gen_x, gen_y), z, w])")
        print("-Each is a disk from gen_x to gen_y with w w-basepoints and z z-basepoints")
        print("-Note: It should all be on the vertical axis")
    elif command == 'calc_Gradings':
        print("-This function eats a complex, and returns a List of i-gradings/j-gradings ")
        print("1.b.i: 'gradings' are a List of: [gen, w, z] for each gen (note: it is really the U^w Translate of gen_)")
    elif command == 'calc_S3':
        print("Feed it the hat complex followed by the grading set for the hat complex")
    elif command == 'get_Tau':
        print("Feed it the S3 gen, and the hat gradings")
    elif command == 'vert_Simplify':
        print("Feed it a complex <output of gen_Complex>, and the gradings for the complex")
    else: print("I can't help you, try again later. (and check your input)")