# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 16:52:10 2020

@author: Rob Quarles
"""
import FT_Interpreter as fti
import FT_Hom_Ops as hom
import ast

def create_file_with_contents(file_name, data):
    file = open(file_name, 'w')
    file.write(data)
    file.close()

def gen_Fourtuple_List(p):
    #Check to see if we've already written it
    f = open("valid_four_tuples.txt", "r")
    for line in f:
        if line == str(p)+":\n":
            print("List already exists for p=", str(p))
            f.close()
            return
    f.close()
    
    #Generate List
    f = open("valid_four_tuples.txt", "a")
    f.write(str(p))
    f.write(":")
    f.write("\n")
    #f.write("[")
    for a in range(1, p):
        for b in range (0, p):
            for r in range(1, p):
                T = [p, a, b, r]
                if fti.fourtuple_Loop(p, a, b, r)[0] == False:
                    #write to valid 4T list
                    f.write(str(T))
                    #f.write( ",")
                    f.write("\n")
    #f.write("]")
    f.close()
    print("Finished")

def gen_Complex_List(T):    
    #Generate Dictionary
    f = open("complexcache.txt", "a")
    f.write(str(T))
    f.write(":")
    f.write("\n")
    com = hom.gen_AGraded_Complex(T)
    f.write(str(com))
    f.write("\n")
    f.close()
    print("Finished", str(T))
    
def get_Valid_Fourtuples_Of_Size(p):
    L = []
    f = open("valid_four_tuples.txt", "r")
    read = False
    for line in f:
        if read and line[0] == "[":
            l = line.strip()
            L.append(ast.literal_eval(l)) 
        if line == str(p)+":\n": #We found p, so start reading the next line
            read= True
        elif line == str(p+1)+":\n" and read:
            break
    f.close()
    return L

def loop_Through_Fourtuples_Of_Size_And_Do(p, APPLY_FUNC, FUNC2 = None): #Pass a function on a 4_Tuple
    f = open("valid_four_tuples.txt", "r")
    read = False
    for line in f:
        if read and line[0] == "[":
            l = ast.literal_eval(line.strip())
            if FUNC2 != None:
                FUNC2(APPLY_FUNC(l))
            else:
                APPLY_FUNC(l)
        if line == str(p)+":\n": #We found p, so start reading the next line
            read= True
        elif line == str(p+1)+":\n" and read:
            break
    f.close()

def get_Complex(T):
    f = open("complexcache.txt", "r")
    read = False
    for line in f:
        if read:
            #Collect Complex
            answer = ast.literal_eval(line)
            
            #Finish Up
            read = False
            break
        if line == str(T)+":\n": #We found T, so start reading the next line
            read= True
    f.close()
    return answer